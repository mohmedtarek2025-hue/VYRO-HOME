@rem
@rem Gradle startup script for Windows (VYRO HOME)
@rem
@if "%DEBUG%"=="" @echo off
set DIRNAME=%~dp0
if "%DIRNAME%"=="" set DIRNAME=.
set APP_HOME=%DIRNAME%
set CLASSPATH=%APP_HOME%\gradle\wrapper\gradle-wrapper.jar

if not exist "%CLASSPATH%" (
    echo Bootstrapping gradle-wrapper.jar...
    powershell -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/gradle/gradle/v8.11.1/gradle/wrapper/gradle-wrapper.jar' -OutFile '%CLASSPATH%'"
)

if defined JAVA_HOME (
    set JAVA_EXE="%JAVA_HOME%/bin/java.exe"
) else (
    set JAVA_EXE="java.exe"
)

%JAVA_EXE% -Xmx64m -Xms64m -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
