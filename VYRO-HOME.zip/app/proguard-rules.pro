# VYRO HOME ProGuard / R8 Rules
-keepattributes *Annotation*,InnerClasses,Signature,EnclosingMethod

# Keep Kotlinx Serialization generated serializers
-keepclassmembers class com.vyro.home.** {
    *** Companion;
}
-keepclasseswithmembers class com.vyro.home.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Keep Room entities & DAOs
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
