package com.vyro.home

import com.vyro.home.data.model.AppCategory
import com.vyro.home.data.model.InstalledAppInfo
import com.vyro.home.data.model.LayoutPresetType
import com.vyro.home.data.model.ThemeArchetype
import com.vyro.home.data.model.WidgetType
import com.vyro.home.domain.engine.AutoLayoutEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VyroEngineUnitTest {

    @Test
    fun autoLayoutEngine_organizesAppsIntoSmartFoldersAndDock() {
        val engine = AutoLayoutEngine()
        val sampleApps = listOf(
            InstalledAppInfo("com.android.dialer", ".Main", "Phone", AppCategory.SOCIAL, true),
            InstalledAppInfo("com.whatsapp", ".Main", "WhatsApp", AppCategory.SOCIAL, false),
            InstalledAppInfo("com.mobilefootie.wc2010", ".Main", "FotMob", AppCategory.FOOTBALL_SPORTS, false),
            InstalledAppInfo("com.ea.gp.fifamobile", ".Main", "EA FC", AppCategory.GAMES, false),
            InstalledAppInfo("com.google.android.gm", ".Main", "Gmail", AppCategory.PRODUCTIVITY, false)
        )

        val layout = engine.generateOptimizedLayout(
            installedApps = sampleApps,
            preset = LayoutPresetType.ONE_UI_ERGONOMIC,
            theme = ThemeArchetype.DARK,
            selectedWidgets = listOf(WidgetType.CLOCK_WEATHER, WidgetType.FOOTBALL_LIVE),
            selectedInterests = listOf("FOOTBALL", "GAMING"),
            isSamsungDevice = true
        )

        assertEquals(4, layout.gridColumns)
        assertEquals(5, layout.gridRows)
        assertTrue(layout.oneUiReachEnabled)
        assertFalse(layout.smartFolders.isEmpty())
        assertEquals(AppCategory.FOOTBALL_SPORTS, layout.smartFolders.first().category)
        assertTrue(layout.dockPackages.isNotEmpty())
    }
}
