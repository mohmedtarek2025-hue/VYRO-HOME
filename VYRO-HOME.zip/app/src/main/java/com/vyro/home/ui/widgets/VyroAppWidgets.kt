package com.vyro.home.ui.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.vyro.home.MainActivity
import com.vyro.home.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class VyroFootballAppWidgetReceiver : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            val intent = Intent(context, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val views = RemoteViews(context.packageName, R.layout.widget_vyro_football).apply {
                setTextViewText(R.id.widget_football_header, "VYRO FOOTBALL HUB")
                setTextViewText(R.id.widget_football_sub, "FC Barcelona • Real Madrid • Egypt")
                setOnClickPendingIntent(R.id.widget_football_root, pendingIntent)
            }
            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}

class VyroClockAppWidgetReceiver : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val dateStr = SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date())
        for (appWidgetId in appWidgetIds) {
            val intent = Intent(context, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                context,
                1,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val views = RemoteViews(context.packageName, R.layout.widget_vyro_clock).apply {
                setTextViewText(R.id.widget_clock_time, timeStr)
                setTextViewText(R.id.widget_clock_date, "$dateStr • VYRO HOME")
                setOnClickPendingIntent(R.id.widget_clock_root, pendingIntent)
            }
            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
