package com.vyro.home.core.device

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.serialization.Serializable

@Serializable
data class DeviceCapabilityReport(
    val manufacturer: String,
    val brand: String,
    val model: String,
    val deviceCode: String,
    val buildDisplay: String,
    val sdkInt: Int,
    val releaseVersion: String,
    val codename: String,
    val isAndroid16Or17Supported: Boolean,
    val androidGenerationLabel: String,
    val isSamsungDevice: Boolean,
    val isOneUiEnvironment: Boolean,
    val semPlatformInt: Int?,
    val oneUiVersionLabel: String,
    val isOneUi9Detected: Boolean,
    val oneUi9DisclosureEn: String,
    val oneUi9DisclosureAr: String,
    val hasGoodLockInstalled: Boolean,
    val hasThemeParkInstalled: Boolean,
    val hasHomeUpInstalled: Boolean,
    val supportsDynamicWallpaperColors: Boolean,
    val supportsSettingsPanels: Boolean,
    val recommendedProfileId: String,
    val recommendedProfileNameEn: String,
    val recommendedProfileNameAr: String
)

/**
 * Runtime hardware, OS, and Samsung One UI environment detector.
 * Strictly uses official Android APIs and safe metadata inspection without relying on
 * undocumented or privileged APIs as mandatory requirements.
 * Never falsely claims One UI 9.0 compatibility on devices where One UI 9.0 is unavailable.
 */
class DeviceCapabilityManager(private val context: Context) {

    fun inspectDevice(): DeviceCapabilityReport {
        val manufacturer = Build.MANUFACTURER ?: "Unknown"
        val brand = Build.BRAND ?: "Unknown"
        val model = Build.MODEL ?: "Android Device"
        val deviceCode = Build.DEVICE ?: "generic"
        val buildDisplay = Build.DISPLAY ?: ""
        val sdkInt = Build.VERSION.SDK_INT
        val release = Build.VERSION.RELEASE ?: "$sdkInt"
        val codename = Build.VERSION.CODENAME ?: "REL"

        val isSamsung = manufacturer.equals("samsung", ignoreCase = true) ||
                brand.equals("samsung", ignoreCase = true)

        val pm = context.packageManager
        val hasSemFeature = pm.hasSystemFeature("com.samsung.feature.samsung_experience_mobile") ||
                pm.hasSystemFeature("com.samsung.feature.samsung_experience_mobile_lite")

        val semPlatformInt = readSemPlatformIntSafely()
        val oneUiProp = readSystemPropertySafely("ro.build.version.oneui")
        val isOneUi = isSamsung && (hasSemFeature || semPlatformInt != null || !oneUiProp.isNullOrBlank())

        val (oneUiLabel, isOneUi9) = resolveOneUiVersion(isOneUi, semPlatformInt, oneUiProp, sdkInt)

        val hasGoodLock = isPackageInstalled(pm, "com.samsung.android.goodlock")
        val hasThemePark = isPackageInstalled(pm, "com.samsung.android.themedesigner")
        val hasHomeUp = isPackageInstalled(pm, "com.samsung.android.app.homestar")

        val androidGenLabel = when {
            sdkInt >= 37 -> "Android 17 (API 37)"
            sdkInt == 36 -> "Android 16 (API 36)"
            else -> "Android API $sdkInt (Unsupported < API 36)"
        }

        val oneUi9DisclosureEn = when {
            isOneUi9 -> "Verified Samsung One UI 9.0 environment detected on Android 17 (API 37). One UI 9.0 ergonomic presets enabled."
            isOneUi -> "Samsung One UI ($oneUiLabel) detected. One UI 9.0 is NOT present on this firmware; VYRO HOME uses compatible One UI presets without falsely claiming One UI 9.0."
            else -> "Non-Samsung device ($manufacturer $model). Samsung One UI 9.0 is unavailable on this hardware; VYRO HOME applies the native ${resolveOemProfileNameEn(manufacturer)} profile."
        }

        val oneUi9DisclosureAr = when {
            isOneUi9 -> "تم التحقق من وجود واجهة Samsung One UI 9.0 على أندرويد 17 (API 37). تم تفعيل إعدادات One UI 9.0 المخصصة."
            isOneUi -> "تم اكتشاف واجهة سامسونج ($oneUiLabel). إصدار One UI 9.0 غير متوفر على هذا الجهاز؛ يستخدم VYRO HOME الإعدادات المتوافقة بصدق دون ادعاء وجود One UI 9.0."
            else -> "جهاز غير تابع لسامسونج ($manufacturer $model). واجهة One UI 9.0 غير متاحة على هذا الجهاز؛ تم تطبيق ملف تخصيص ${resolveOemProfileNameAr(manufacturer)}."
        }

        return DeviceCapabilityReport(
            manufacturer = manufacturer,
            brand = brand,
            model = model,
            deviceCode = deviceCode,
            buildDisplay = buildDisplay,
            sdkInt = sdkInt,
            releaseVersion = release,
            codename = codename,
            isAndroid16Or17Supported = sdkInt in 36..37,
            androidGenerationLabel = androidGenLabel,
            isSamsungDevice = isSamsung,
            isOneUiEnvironment = isOneUi,
            semPlatformInt = semPlatformInt,
            oneUiVersionLabel = oneUiLabel,
            isOneUi9Detected = isOneUi9,
            oneUi9DisclosureEn = oneUi9DisclosureEn,
            oneUi9DisclosureAr = oneUi9DisclosureAr,
            hasGoodLockInstalled = hasGoodLock,
            hasThemeParkInstalled = hasThemePark,
            hasHomeUpInstalled = hasHomeUp,
            supportsDynamicWallpaperColors = sdkInt >= 36,
            supportsSettingsPanels = true,
            recommendedProfileId = resolveOemProfileId(manufacturer, isOneUi, isOneUi9),
            recommendedProfileNameEn = resolveOemProfileNameEn(manufacturer, isOneUi, isOneUi9),
            recommendedProfileNameAr = resolveOemProfileNameAr(manufacturer, isOneUi, isOneUi9)
        )
    }

    private fun readSemPlatformIntSafely(): Int? {
        return try {
            val field = Build.VERSION::class.java.getDeclaredField("SEM_PLATFORM_INT")
            field.isAccessible = true
            val value = field.getInt(null)
            if (value > 0) value else null
        } catch (_: Throwable) {
            null
        }
    }

    private fun readSystemPropertySafely(key: String): String? {
        return try {
            val systemProperties = Class.forName("android.os.SystemProperties")
            val getMethod = systemProperties.getMethod("get", String::class.java, String::class.java)
            val result = getMethod.invoke(null, key, "") as? String
            result?.takeIf { it.isNotBlank() }
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Resolves Samsung One UI version from official SEM_PLATFORM_INT or ro.build.version.oneui.
     * Formula for SEM_PLATFORM_INT: major = (SEM_PLATFORM_INT - 90000) / 10000, minor = ((SEM_PLATFORM_INT % 10000) / 100)
     * Example:
     * - 160000 -> One UI 7.0
     * - 170000 -> One UI 8.0 (Android 16)
     * - 180000 -> One UI 9.0 (Android 17)
     */
    private fun resolveOneUiVersion(
        isOneUi: Boolean,
        semPlatformInt: Int?,
        oneUiProp: String?,
        sdkInt: Int
    ): Pair<String, Boolean> {
        if (!isOneUi) return "Not Applicable (Non-Samsung)" to false

        if (!oneUiProp.isNullOrBlank()) {
            val code = oneUiProp.toIntOrNull()
            if (code != null && code >= 10000) {
                val major = code / 10000
                val minor = (code % 10000) / 100
                return "One UI $major.$minor" to (major == 9)
            }
        }

        if (semPlatformInt != null && semPlatformInt >= 100000) {
            val major = (semPlatformInt - 90000) / 10000
            val minor = (semPlatformInt % 10000) / 100
            return "One UI $major.$minor" to (major == 9)
        }

        // Honest fallback when on a Samsung device that hides SEM_PLATFORM_INT:
        return "Samsung One UI (API $sdkInt Edition — Exact One UI 9.0 Unverified)" to false
    }

    private fun isPackageInstalled(pm: PackageManager, packageName: String): Boolean {
        return try {
            pm.getPackageInfo(packageName, 0)
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun resolveOemProfileId(manufacturer: String, isOneUi: Boolean = false, isOneUi9: Boolean = false): String {
        val m = manufacturer.lowercase()
        return when {
            isOneUi9 -> "SAMSUNG_ONEUI_9"
            isOneUi || m.contains("samsung") -> "SAMSUNG_ONEUI"
            m.contains("google") -> "GOOGLE_PIXEL_16"
            m.contains("xiaomi") || m.contains("redmi") || m.contains("poco") -> "XIAOMI_HYPEROS"
            m.contains("nothing") -> "NOTHING_MATRIX"
            m.contains("oneplus") || m.contains("oppo") || m.contains("realme") -> "OXYGEN_FLUID"
            else -> "VYRO_UNIVERSAL_AOSP"
        }
    }

    private fun resolveOemProfileNameEn(manufacturer: String, isOneUi: Boolean = false, isOneUi9: Boolean = false): String {
        val m = manufacturer.lowercase()
        return when {
            isOneUi9 -> "Samsung One UI 9.0 Next-Gen Profile"
            isOneUi || m.contains("samsung") -> "Samsung One UI Ergonomic Profile"
            m.contains("google") -> "Google Pixel Material You Profile"
            m.contains("xiaomi") || m.contains("redmi") || m.contains("poco") -> "Xiaomi HyperOS Glass Profile"
            m.contains("nothing") -> "Nothing Monochrome Matrix Profile"
            m.contains("oneplus") || m.contains("oppo") -> "OxygenOS Fluid Cyber Profile"
            else -> "VYRO Universal Android 16/17 Profile"
        }
    }

    private fun resolveOemProfileNameAr(manufacturer: String, isOneUi: Boolean = false, isOneUi9: Boolean = false): String {
        val m = manufacturer.lowercase()
        return when {
            isOneUi9 -> "ملف سامسونج One UI 9.0 المتطور"
            isOneUi || m.contains("samsung") -> "ملف سامسونج One UI المريح"
            m.contains("google") -> "ملف جوجل بيكسل Material You"
            m.contains("xiaomi") || m.contains("redmi") || m.contains("poco") -> "ملف شاومي HyperOS الزجاجي"
            m.contains("nothing") -> "ملف Nothing الرقمي"
            m.contains("oneplus") || m.contains("oppo") -> "ملف OxygenOS الانسيابي"
            else -> "ملف فايرو القياسي لأندرويد 16/17"
        }
    }
}
