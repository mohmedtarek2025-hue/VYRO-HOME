package com.vyro.home.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyro.home.ui.viewmodel.VyroUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickControlPanelSheet(
    uiState: VyroUiState,
    onDismiss: () -> Unit,
    onWifiClick: () -> Unit,
    onBluetoothClick: () -> Unit,
    onVolumePanelClick: () -> Unit,
    onMediaVolumeChange: (Int) -> Unit,
    onRingVolumeChange: (Int) -> Unit,
    onBrightnessChange: (Int) -> Unit,
    onToggleFlashlight: () -> Unit,
    onToggleDarkAmoled: () -> Unit,
    onOpenFootballHub: () -> Unit,
    onOpenLockStudio: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val isAr = uiState.isArabic
    val telemetry = uiState.systemTelemetry

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0F172A),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = if (isAr) "مركز تحكم VYRO السريع (مستوحى من One UI)" else "VYRO CONTROL CENTER (One UI Inspired)",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.ExtraBold
            )

            Text(
                text = if (isAr) {
                    "يستخدم واجهات أندرويد الرسمية (Settings.Panel و AudioManager و CameraManager) كواجهة تحكم سريعة بديلة ومكملة للوحة النظام."
                } else {
                    "Uses official Android APIs (Settings.Panel, AudioManager, CameraManager) as a legitimate launcher control center without modifying restricted SystemUI partitions."
                },
                fontSize = 11.sp,
                color = Color(0xFF94A3B8)
            )

            // Primary Quick Tiles Row 1
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilledTonalButton(
                    onClick = onWifiClick,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.Wifi, contentDescription = null)
                    Text(if (isAr) " واي فاي" else " Wi-Fi Panel")
                }

                FilledTonalButton(
                    onClick = onBluetoothClick,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.Bluetooth, contentDescription = null)
                    Text(if (isAr) " بلوتوث" else " Bluetooth")
                }
            }

            // Primary Quick Tiles Row 2
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilledTonalButton(
                    onClick = onToggleFlashlight,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.FlashlightOn, contentDescription = null)
                    Text(
                        if (telemetry.isTorchEnabled) {
                            if (isAr) " الكشاف: يعمل" else " Torch: ON"
                        } else {
                            if (isAr) " الكشاف" else " Flashlight"
                        }
                    )
                }

                FilledTonalButton(
                    onClick = onToggleDarkAmoled,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.DarkMode, contentDescription = null)
                    Text(if (isAr) " وضع AMOLED" else " AMOLED Mode")
                }
            }

            // Brightness Slider
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Brightness6, contentDescription = null, tint = Color.White)
                            Text(
                                text = if (isAr) "  سطوع الشاشة (${telemetry.brightnessPercent}%)"
                                else "  Screen Brightness (${telemetry.brightnessPercent}%)",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        if (!telemetry.canWriteSystemSettings) {
                            Text(
                                text = if (isAr) "اضغط لمنح الإذن" else "Tap slider to grant permission",
                                fontSize = 10.sp,
                                color = Color(0xFFF59E0B)
                            )
                        }
                    }
                    Slider(
                        value = telemetry.brightnessPercent.toFloat(),
                        onValueChange = { onBrightnessChange(it.toInt()) },
                        valueRange = 5f..100f
                    )
                }
            }

            // Media & Ring Volume Sliders
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color.White)
                            Text(
                                text = if (isAr) "  مستوى صوت الوسائط (${telemetry.mediaVolumePercent}%)"
                                else "  Media Volume (${telemetry.mediaVolumePercent}%)",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        FilledTonalButton(onClick = onVolumePanelClick) {
                            Text(if (isAr) "لوحة الصوت" else "System Mixer", fontSize = 11.sp)
                        }
                    }
                    Slider(
                        value = telemetry.mediaVolumePercent.toFloat(),
                        onValueChange = { onMediaVolumeChange(it.toInt()) },
                        valueRange = 0f..100f
                    )

                    Text(
                        text = if (isAr) "صوت الرنين (${telemetry.ringVolumePercent}%)"
                        else "Ringtone Volume (${telemetry.ringVolumePercent}%)",
                        color = Color(0xFFCBD5E1),
                        fontSize = 12.sp
                    )
                    Slider(
                        value = telemetry.ringVolumePercent.toFloat(),
                        onValueChange = { onRingVolumeChange(it.toInt()) },
                        valueRange = 0f..100f
                    )
                }
            }

            // Battery & App Shortcuts Row
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(18.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.BatteryChargingFull,
                            contentDescription = null,
                            tint = Color(0xFF10B981)
                        )
                        Text(
                            text = if (isAr) {
                                " البطارية: ${telemetry.batteryPercent}% • ${telemetry.batteryTempCelsius}°C • ${telemetry.batteryVoltageMv}mV"
                            } else {
                                " Battery: ${telemetry.batteryPercent}% • ${telemetry.batteryTempCelsius}°C • ${telemetry.batteryVoltageMv}mV"
                            },
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Custom VYRO Shortcut Tiles
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(onClick = onOpenFootballHub, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.SportsSoccer, contentDescription = null)
                    Text(if (isAr) " الكرة" else " Football")
                }
                FilledTonalButton(onClick = onOpenLockStudio, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Lock, contentDescription = null)
                    Text(if (isAr) " القفل" else " Lock UI")
                }
                FilledTonalButton(onClick = onOpenSettings, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Settings, contentDescription = null)
                    Text(if (isAr) " الإعدادات" else " Settings")
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}
