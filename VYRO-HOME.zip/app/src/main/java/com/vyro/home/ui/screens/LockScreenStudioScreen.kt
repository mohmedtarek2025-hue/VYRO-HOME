package com.vyro.home.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyro.home.data.model.ClockStylePreset
import com.vyro.home.data.model.LockNotificationPrivacy
import com.vyro.home.data.model.LockScreenConfig
import com.vyro.home.data.model.WallpaperPreset
import com.vyro.home.ui.viewmodel.VyroUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LockScreenStudioScreen(
    uiState: VyroUiState,
    onSaveLockConfig: (LockScreenConfig, Boolean) -> Unit,
    onLaunchCompanionPreview: () -> Unit,
    onBack: () -> Unit
) {
    val isAr = uiState.isArabic
    val initial = uiState.preferences.lockScreenConfig

    var clockStyle by remember { mutableStateOf(initial.clockStyle) }
    var showDate by remember { mutableStateOf(initial.showDate) }
    var showWeather by remember { mutableStateOf(initial.showWeather) }
    var showFootball by remember { mutableStateOf(initial.showFootballWidget) }
    var wallpaper by remember { mutableStateOf(initial.wallpaperPreset) }
    var privacy by remember { mutableStateOf(initial.notificationPrivacy) }
    var syncSystemLockWallpaper by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = if (isAr) "تخصيص شاشة القفل VYRO" else "VYRO LOCK-SCREEN STUDIO",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Security Disclosure Card (Requirement 6)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (isAr) "حماية أمان أندرويد 16/17 الأصلية" else "Android 16/17 Native Lock-Screen Security",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = if (isAr) {
                                "يحترم VYRO HOME تشفير شاشة القفل والبصمة ورمز PIN الخاص بالنظام ولا يتجاوزها أبداً. يقوم بتطبيق خلفيات القفل عبر WallpaperManager(FLAG_LOCK) ويوفر شاشة القفل التفاعلية المصاحبة."
                            } else {
                                "VYRO HOME strictly respects Android Keyguard, PIN, and biometric security. It applies lock wallpapers via official WallpaperManager(FLAG_LOCK) and provides an opt-in Ambient Lock-Screen Companion."
                            },
                            fontSize = 12.sp,
                            color = Color(0xFFCBD5E1)
                        )
                    }
                }
            }

            // Live Interactive Lock Screen Preview Card
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(wallpaper.topColorHex), Color(wallpaper.midColorHex), Color(wallpaper.bottomColorHex))
                            ),
                            RoundedCornerShape(22.dp)
                        )
                        .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(22.dp))
                        .padding(18.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = Color.White)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = when (clockStyle) {
                                    ClockStylePreset.ARABIC_MODERN -> "٠٩:٤٥"
                                    ClockStylePreset.ONEUI_STACKED -> "09\n45"
                                    else -> "09:45"
                                },
                                fontSize = if (clockStyle == ClockStylePreset.ONEUI_STACKED) 30.sp else 38.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            if (showDate) {
                                Text(
                                    text = if (isAr) "الأربعاء، ١٨ نوفمبر • ٢٤°م" else "Wednesday, Nov 18 • ${if (showWeather) "24°C Clear" else ""}",
                                    color = Color(0xFFCBD5E1),
                                    fontSize = 12.sp
                                )
                            }
                        }
                        if (showFootball) {
                            Text(
                                text = "⚽ ${uiState.preferences.primaryTeamId} Matchday Live Pill",
                                color = Color(0xFF34D399),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Clock Style Selector
            item {
                Text(
                    text = if (isAr) "نمط الساعة" else "Clock Style",
                    style = MaterialTheme.typography.titleMedium
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ClockStylePreset.entries.forEach { preset ->
                        FilterChip(
                            selected = clockStyle == preset,
                            onClick = { clockStyle = preset },
                            label = { Text(if (isAr) preset.nameAr else preset.nameEn) }
                        )
                    }
                }
            }

            // Toggles
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (isAr) "إظهار التاريخ والطقس" else "Show Date & Weather Telemetry")
                    Switch(checked = showDate && showWeather, onCheckedChange = {
                        showDate = it
                        showWeather = it
                    })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (isAr) "إظهار ودجت كرة القدم على شاشة القفل" else "Show Football Matchday Lock Widget")
                    Switch(checked = showFootball, onCheckedChange = { showFootball = it })
                }
            }

            // Notification Privacy Level
            item {
                Text(
                    text = if (isAr) "خصوصية الإشعارات" else "Lock-Screen Notification Privacy",
                    style = MaterialTheme.typography.titleMedium
                )
                LockNotificationPrivacy.entries.forEach { mode ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(if (isAr) mode.labelAr else mode.labelEn, fontSize = 13.sp)
                        Checkbox(checked = privacy == mode, onCheckedChange = { if (it) privacy = mode })
                    }
                }
            }

            // System Lock Screen Wallpaper Sync
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (isAr) "تطبيق الخلفية على شاشة قفل النظام (FLAG_LOCK)" else "Apply Wallpaper to System Lock Screen (FLAG_LOCK)",
                        modifier = Modifier.weight(1f)
                    )
                    Checkbox(checked = syncSystemLockWallpaper, onCheckedChange = { syncSystemLockWallpaper = it })
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onLaunchCompanionPreview,
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Visibility, contentDescription = null)
                Spacer(modifier = Modifier.height(4.dp))
                Text(if (isAr) "معاينة حية" else "Live Companion")
            }
            Button(
                onClick = {
                    val updated = LockScreenConfig(
                        clockStyle = clockStyle,
                        showDate = showDate,
                        showWeather = showWeather,
                        showFootballWidget = showFootball,
                        wallpaperPreset = wallpaper,
                        accentColorHex = uiState.preferences.customAccentHex,
                        notificationPrivacy = privacy
                    )
                    onSaveLockConfig(updated, syncSystemLockWallpaper)
                },
                modifier = Modifier.weight(1.2f)
            ) {
                Text(if (isAr) "حفظ وتطبيق" else "Save & Apply Lock Config")
            }
        }
    }
}
