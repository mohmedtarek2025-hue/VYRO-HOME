package com.vyro.home.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyro.home.data.model.AppCategory
import com.vyro.home.data.model.InstalledAppInfo
import com.vyro.home.data.model.LayoutPresetType
import com.vyro.home.data.model.SmartFolderModel
import com.vyro.home.data.model.WidgetType
import com.vyro.home.ui.theme.resolveIconShape
import com.vyro.home.ui.viewmodel.VyroUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun HomeWorkspaceScreen(
    uiState: VyroUiState,
    onLaunchApp: (InstalledAppInfo) -> Unit,
    onOpenAppInfo: (String) -> Unit,
    onOpenFootballHub: () -> Unit,
    onOpenQuickControl: () -> Unit,
    onOpenLockStudio: () -> Unit,
    onOpenSamsungCenter: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenWizard: () -> Unit,
    onUndoLayout: () -> Unit,
    onSelectPreset: (LayoutPresetType) -> Unit,
    onCreateCustomFolder: (String, String, List<String>) -> Unit,
    onDismissBanner: () -> Unit
) {
    val isAr = uiState.isArabic
    val prefs = uiState.preferences
    val layout = prefs.activeLayoutState
    val wp = prefs.wallpaperPreset
    val iconShape = resolveIconShape(prefs.iconShapeStyle)

    var showAppDrawer by remember { mutableStateOf(false) }
    var isEditMode by remember { mutableStateOf(false) }
    var activeSmartFolder by remember { mutableStateOf<SmartFolderModel?>(null) }
    var showCreateFolderDialog by remember { mutableStateOf(false) }

    val appsByPackage = remember(uiState.installedApps) {
        uiState.installedApps.associateBy { it.packageName }
    }

    val backgroundBrush = Brush.verticalGradient(
        colors = if (prefs.themeArchetype.isAmoled) {
            listOf(Color.Black, Color(0xFF050508), Color.Black)
        } else {
            listOf(
                Color(wp.topColorHex),
                Color(wp.midColorHex),
                Color(wp.bottomColorHex)
            )
        }
    )

    val timeStr = remember {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
    }
    val dateStr = remember(isAr) {
        SimpleDateFormat(
            if (isAr) "EEEE، d MMMM yyyy" else "EEEE, MMM d",
            if (isAr) Locale("ar") else Locale.ENGLISH
        ).format(Date())
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundBrush)
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Action & Telemetry Strip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AssistChip(
                        onClick = onOpenSamsungCenter,
                        label = {
                            Text(
                                text = if (uiState.deviceReport.isSamsungDevice) {
                                    uiState.deviceReport.oneUiVersionLabel
                                } else {
                                    "Android ${uiState.deviceReport.releaseVersion}"
                                },
                                fontSize = 11.sp
                            )
                        },
                        leadingIcon = {
                            Icon(Icons.Default.PhoneAndroid, contentDescription = null, modifier = Modifier.size(15.dp))
                        }
                    )

                    AssistChip(
                        onClick = onOpenFootballHub,
                        label = {
                            Text(
                                text = prefs.primaryTeamId,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        leadingIcon = {
                            Icon(Icons.Default.SportsSoccer, contentDescription = null, modifier = Modifier.size(15.dp))
                        }
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = { isEditMode = !isEditMode }) {
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = "Edit Layout",
                            tint = if (isEditMode) MaterialTheme.colorScheme.primary else Color.White
                        )
                    }
                    IconButton(onClick = onOpenQuickControl) {
                        Icon(Icons.Default.Tune, contentDescription = "Quick Control Center", tint = Color.White)
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                    }
                }
            }

            // Status / Undo notification banner if present
            AnimatedVisibility(visible = uiState.statusBannerMessage != null) {
                uiState.statusBannerMessage?.let { msg ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { onDismissBanner() },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Text(
                            text = msg,
                            modifier = Modifier.padding(10.dp),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Edit Mode Toolbar (Undo Changes / Presets / New Folder / Re-run Wizard)
            AnimatedVisibility(visible = isEditMode) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xDD111827))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isAr) "محرك التخطيط التلقائي" else "VYRO Auto-Layout Engine",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                TextButton(onClick = onUndoLayout) {
                                    Icon(Icons.Default.Undo, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (isAr) "تراجع" else "Undo")
                                }
                                TextButton(onClick = { showCreateFolderDialog = true }) {
                                    Icon(Icons.Default.CreateNewFolder, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (isAr) "مجلد+" else "+Folder")
                                }
                                TextButton(onClick = onOpenWizard) {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (isAr) "المعالج" else "Wizard")
                                }
                            }
                        }

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(LayoutPresetType.entries) { preset ->
                                FilterChip(
                                    selected = layout.presetType == preset,
                                    onClick = { onSelectPreset(preset) },
                                    label = { Text(if (isAr) preset.nameAr else preset.nameEn, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
            }

            // Optional Samsung One UI Ergonomic Reach Header
            if (layout.oneUiReachEnabled) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = timeStr,
                            fontSize = 44.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Text(
                            text = "$dateStr • ${if (isAr) "وضع الوصول بيد واحدة One UI" else "One UI Thumb-Reach Zone"}",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
            }

            // Workspace Middle Area: Widgets + Smart Folders + Favorite App Grid
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Active Widgets Row
                if (layout.activeWidgets.contains(WidgetType.CLOCK_WEATHER) && !layout.oneUiReachEnabled) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0x331E293B))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = timeStr,
                                    fontSize = 34.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                                Text(
                                    text = dateStr,
                                    fontSize = 13.sp,
                                    color = Color(0xFFCBD5E1)
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.BatteryChargingFull,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "${uiState.systemTelemetry.batteryPercent}% • ${uiState.systemTelemetry.batteryTempCelsius}°C",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                                Text(
                                    text = uiState.deviceReport.recommendedProfileNameEn,
                                    fontSize = 11.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }
                    }
                }

                // Football Live Hub Widget on Home Screen
                if (layout.activeWidgets.contains(WidgetType.FOOTBALL_LIVE)) {
                    val fb = uiState.footballSnapshot
                    val primaryTeam = fb?.team
                    val nextMatch = fb?.matches?.firstOrNull()
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenFootballHub() },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color(primaryTeam?.primaryColorHex ?: 0xFF0E291E).copy(alpha = 0.28f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isAr) {
                                        "مركز كرة القدم • ${primaryTeam?.nameAr ?: "برشلونة"}"
                                    } else {
                                        "FOOTBALL HUB • ${primaryTeam?.nameEn ?: "FC Barcelona"}"
                                    },
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                if (nextMatch != null) {
                                    val scoreLabel = if (nextMatch.homeScore != null && nextMatch.awayScore != null) {
                                        "${nextMatch.homeScore} - ${nextMatch.awayScore}"
                                    } else {
                                        "VS"
                                    }
                                    Text(
                                        text = "${if (isAr) nextMatch.homeTeamAr else nextMatch.homeTeamEn}  $scoreLabel  ${if (isAr) nextMatch.awayTeamAr else nextMatch.awayTeamEn}",
                                        color = Color(0xFFF8FAFC),
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "${nextMatch.competitionName} • ${nextMatch.status}",
                                        color = Color(0xFFCBD5E1),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                            Icon(
                                Icons.Default.SportsSoccer,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }

                // Smart Folders Section
                Text(
                    text = if (isAr) "المجلدات الذكية التلقائية" else "SMART AUTO-FOLDERS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 2.dp)
                ) {
                    items(layout.smartFolders) { folder ->
                        Card(
                            modifier = Modifier
                                .width(142.dp)
                                .clickable { activeSmartFolder = folder },
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0x381E293B))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Folder,
                                        contentDescription = null,
                                        tint = Color(folder.accentHex),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "${folder.appPackages.size}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (isAr) folder.titleAr else folder.titleEn,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }

                // Favorite Apps Workspace Grid
                Text(
                    text = if (isAr) "تطبيقات الشاشة الرئيسية (${layout.gridColumns}×${layout.gridRows})" else "WORKSPACE FAVORITES (${layout.gridColumns}x${layout.gridRows})",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8)
                )

                val favoriteApps = layout.favoritePackages.mapNotNull { appsByPackage[it] }
                    .ifEmpty { uiState.installedApps.take(layout.gridColumns * 2) }

                LazyVerticalGrid(
                    columns = GridCells.Fixed(layout.gridColumns.coerceIn(3, 6)),
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(favoriteApps) { app ->
                        AppIconCell(
                            app = app,
                            iconShape = iconShape,
                            iconScale = layout.iconScale,
                            accentColor = MaterialTheme.colorScheme.primary,
                            onClick = { onLaunchApp(app) },
                            onLongClick = { onOpenAppInfo(app.packageName) }
                        )
                    }
                }
            }

            // Bottom Custom Dock + App Drawer & Lock Studio Triggers
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                color = Color(0x441E293B),
                shape = RoundedCornerShape(26.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val dockApps = layout.dockPackages.mapNotNull { appsByPackage[it] }
                        .ifEmpty { uiState.installedApps.take(4) }

                    dockApps.take(layout.dockCount).forEach { app ->
                        Box(
                            modifier = Modifier
                                .size((48 * layout.iconScale).dp)
                                .clip(iconShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.22f))
                                .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f), iconShape)
                                .clickable { onLaunchApp(app) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = app.label.take(2).uppercase(),
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp
                            )
                        }
                    }

                    // Lock Screen Studio Button
                    IconButton(
                        onClick = onOpenLockStudio,
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Color(0x33FFFFFF))
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = "Lock Screen Studio", tint = Color.White)
                    }

                    // All Apps Drawer Button
                    IconButton(
                        onClick = { showAppDrawer = true },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(
                            Icons.Default.Apps,
                            contentDescription = "All Apps Drawer",
                            tint = Color(0xFF040814)
                        )
                    }
                }
            }
        }
    }

    // Smart Folder Modal Dialog
    activeSmartFolder?.let { folder ->
        val folderApps = folder.appPackages.mapNotNull { appsByPackage[it] }
        AlertDialog(
            onDismissRequest = { activeSmartFolder = null },
            title = {
                Text(
                    text = if (isAr) folder.titleAr else folder.titleEn,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.height(260.dp)
                ) {
                    items(folderApps) { app ->
                        AppIconCell(
                            app = app,
                            iconShape = iconShape,
                            iconScale = 0.95f,
                            accentColor = Color(folder.accentHex),
                            onClick = {
                                activeSmartFolder = null
                                onLaunchApp(app)
                            },
                            onLongClick = { onOpenAppInfo(app.packageName) }
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { activeSmartFolder = null }) {
                    Text(if (isAr) "إغلاق" else "Close")
                }
            }
        )
    }

    // Create Custom Smart Folder Dialog
    if (showCreateFolderDialog) {
        var folderNameEn by remember { mutableStateOf("") }
        var folderNameAr by remember { mutableStateOf("") }
        val chosenApps = remember { mutableStateListOf<String>() }

        AlertDialog(
            onDismissRequest = { showCreateFolderDialog = false },
            title = {
                Text(if (isAr) "إنشاء مجلد ذكي داخل VYRO HOME" else "Create VYRO Smart Folder")
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = folderNameEn,
                        onValueChange = { folderNameEn = it },
                        label = { Text(if (isAr) "اسم المجلد (إنجليزي)" else "Folder Name (English)") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = folderNameAr,
                        onValueChange = { folderNameAr = it },
                        label = { Text(if (isAr) "اسم المجلد (عربي)" else "Folder Name (Arabic)") },
                        singleLine = true
                    )
                    Text(
                        text = if (isAr) "اختر التطبيقات:" else "Select Apps:",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp
                    )
                    LazyColumn(modifier = Modifier.height(180.dp)) {
                        items(uiState.installedApps) { app ->
                            val isChecked = chosenApps.contains(app.packageName)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (isChecked) chosenApps.remove(app.packageName)
                                        else chosenApps.add(app.packageName)
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(app.label, fontSize = 13.sp)
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = {
                                        if (it) chosenApps.add(app.packageName)
                                        else chosenApps.remove(app.packageName)
                                    }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onCreateCustomFolder(
                        folderNameEn.ifBlank { "Custom Folder" },
                        folderNameAr.ifBlank { folderNameEn.ifBlank { "مجلد مخصص" } },
                        chosenApps.toList()
                    )
                    showCreateFolderDialog = false
                }) {
                    Text(if (isAr) "إنشاء" else "Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateFolderDialog = false }) {
                    Text(if (isAr) "إلغاء" else "Cancel")
                }
            }
        )
    }

    // Searchable Categorized App Drawer Bottom Sheet
    if (showAppDrawer) {
        var searchQuery by remember { mutableStateOf("") }
        var selectedCategoryFilter by remember { mutableStateOf<AppCategory?>(null) }

        ModalBottomSheet(
            onDismissRequest = { showAppDrawer = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = {
                        Text(if (isAr) "ابحث في التطبيقات المثبتة..." else "Search installed apps...")
                    },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(
                            selected = selectedCategoryFilter == null,
                            onClick = { selectedCategoryFilter = null },
                            label = { Text(if (isAr) "الكل (${uiState.installedApps.size})" else "All (${uiState.installedApps.size})") }
                        )
                    }
                    items(AppCategory.entries) { cat ->
                        FilterChip(
                            selected = selectedCategoryFilter == cat,
                            onClick = { selectedCategoryFilter = cat },
                            label = { Text(if (isAr) cat.titleAr else cat.titleEn) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                val filteredApps = uiState.installedApps.filter { app ->
                    val matchesSearch = searchQuery.isBlank() ||
                            app.label.contains(searchQuery, ignoreCase = true) ||
                            app.packageName.contains(searchQuery, ignoreCase = true)
                    val matchesCat = selectedCategoryFilter == null || app.category == selectedCategoryFilter
                    matchesSearch && matchesCat
                }

                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredApps) { app ->
                        AppIconCell(
                            app = app,
                            iconShape = iconShape,
                            iconScale = 1.0f,
                            accentColor = MaterialTheme.colorScheme.primary,
                            onClick = {
                                showAppDrawer = false
                                onLaunchApp(app)
                            },
                            onLongClick = { onOpenAppInfo(app.packageName) }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppIconCell(
    app: InstalledAppInfo,
    iconShape: androidx.compose.ui.graphics.Shape,
    iconScale: Float,
    accentColor: Color,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size((52 * iconScale).dp)
                .clip(iconShape)
                .background(
                    Brush.linearGradient(
                        listOf(
                            accentColor.copy(alpha = 0.28f),
                            Color(0xFF1E293B)
                        )
                    )
                )
                .border(1.dp, accentColor.copy(alpha = 0.55f), iconShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = app.label.take(2).uppercase(),
                color = Color.White,
                fontWeight = FontWeight.ExtraBold,
                fontSize = (15 * iconScale).sp
            )
        }
        Spacer(modifier = Modifier.height(5.dp))
        Text(
            text = app.label,
            color = Color.White,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}
