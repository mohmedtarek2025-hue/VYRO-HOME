package com.vyro.home.ui.navigation

import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.vyro.home.ui.screens.FootballHubScreen
import com.vyro.home.ui.screens.HomeWorkspaceScreen
import com.vyro.home.ui.screens.LockScreenStudioScreen
import com.vyro.home.ui.screens.PersonalizationWizardScreen
import com.vyro.home.ui.screens.QuickControlPanelSheet
import com.vyro.home.ui.screens.SamsungExperienceScreen
import com.vyro.home.ui.screens.SettingsScreen
import com.vyro.home.ui.screens.StartScreen
import com.vyro.home.ui.screens.VyroLockScreenCompanionActivity
import com.vyro.home.ui.viewmodel.VyroMainViewModel
import com.vyro.home.ui.viewmodel.VyroUiState

object VyroRoutes {
    const val START = "start_screen"
    const val WIZARD = "personalization_wizard"
    const val HOME = "home_workspace"
    const val FOOTBALL_HUB = "football_hub"
    const val LOCK_STUDIO = "lock_screen_studio"
    const val SAMSUNG_EXPERIENCE = "samsung_experience"
    const val SETTINGS = "settings_screen"
}

@Composable
fun VyroNavHost(
    viewModel: VyroMainViewModel,
    uiState: VyroUiState,
    openQuickControlInitially: Boolean = false
) {
    val navController = rememberNavController()
    val context = LocalContext.current
    var showQuickControlSheet by rememberSaveable { mutableStateOf(openQuickControlInitially) }

    val startDestination = if (uiState.preferences.onboardingCompleted) {
        VyroRoutes.HOME
    } else {
        VyroRoutes.START
    }

    LaunchedEffect(openQuickControlInitially) {
        if (openQuickControlInitially) {
            showQuickControlSheet = true
        }
    }

    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(VyroRoutes.START) {
            StartScreen(
                uiState = uiState,
                onToggleLanguage = { tag -> viewModel.switchLanguage(tag) },
                onStartClicked = {
                    navController.navigate(VyroRoutes.WIZARD)
                },
                onSkipToHome = {
                    navController.navigate(VyroRoutes.HOME) {
                        popUpTo(VyroRoutes.START) { inclusive = true }
                    }
                }
            )
        }

        composable(VyroRoutes.WIZARD) {
            PersonalizationWizardScreen(
                uiState = uiState,
                onGeneratePreview = viewModel::generateWizardPreview,
                onConfirmApply = { applyWp ->
                    viewModel.confirmAndApplyPreviewLayout(applyWp)
                    navController.navigate(VyroRoutes.HOME) {
                        popUpTo(VyroRoutes.START) { inclusive = true }
                    }
                },
                onDiscardPreview = viewModel::discardPreviewCandidate,
                onBack = { navController.popBackStack() }
            )
        }

        composable(VyroRoutes.HOME) {
            HomeWorkspaceScreen(
                uiState = uiState,
                onLaunchApp = viewModel::launchInstalledApp,
                onOpenAppInfo = viewModel::openAppDetails,
                onOpenFootballHub = { navController.navigate(VyroRoutes.FOOTBALL_HUB) },
                onOpenQuickControl = {
                    viewModel.refreshSystemTelemetry()
                    showQuickControlSheet = true
                },
                onOpenLockStudio = { navController.navigate(VyroRoutes.LOCK_STUDIO) },
                onOpenSamsungCenter = { navController.navigate(VyroRoutes.SAMSUNG_EXPERIENCE) },
                onOpenSettings = { navController.navigate(VyroRoutes.SETTINGS) },
                onOpenWizard = { navController.navigate(VyroRoutes.WIZARD) },
                onUndoLayout = viewModel::undoLastLayoutChange,
                onSelectPreset = viewModel::applyQuickPreset,
                onCreateCustomFolder = viewModel::createCustomSmartFolder,
                onDismissBanner = viewModel::clearStatusBanner
            )
        }

        composable(VyroRoutes.FOOTBALL_HUB) {
            FootballHubScreen(
                uiState = uiState,
                onSelectTeam = viewModel::selectPrimaryFootballTeam,
                onRefreshHub = { viewModel.refreshFootballHub() },
                onSaveApiConfig = viewModel::saveFootballApiConfiguration,
                onSendTestNotification = viewModel::triggerMatchTestNotification,
                onBack = { navController.popBackStack() }
            )
        }

        composable(VyroRoutes.LOCK_STUDIO) {
            LockScreenStudioScreen(
                uiState = uiState,
                onSaveLockConfig = viewModel::updateLockScreenConfig,
                onLaunchCompanionPreview = {
                    context.startActivity(Intent(context, VyroLockScreenCompanionActivity::class.java))
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(VyroRoutes.SAMSUNG_EXPERIENCE) {
            SamsungExperienceScreen(
                uiState = uiState,
                onToggleReachMode = viewModel::toggleOneUiReachMode,
                onSelectIconShape = viewModel::selectIconShape,
                onApplyOneUiPreset = {
                    viewModel.applyQuickPreset(com.vyro.home.data.model.LayoutPresetType.ONE_UI_ERGONOMIC)
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(VyroRoutes.SETTINGS) {
            SettingsScreen(
                uiState = uiState,
                onSwitchLanguage = viewModel::switchLanguage,
                onSelectTheme = viewModel::selectTheme,
                onSelectWallpaper = viewModel::selectWallpaperAndApply,
                onSelectIconShape = viewModel::selectIconShape,
                onUpdateGridAndScale = viewModel::updateGridAndScale,
                onUndoLayout = viewModel::undoLastLayoutChange,
                onRestoreSnapshot = viewModel::restoreSnapshot,
                onExportBackup = viewModel::exportBackupToUri,
                onImportBackup = viewModel::importBackupFromUri,
                onOpenFootballHub = { navController.navigate(VyroRoutes.FOOTBALL_HUB) },
                onOpenLockStudio = { navController.navigate(VyroRoutes.LOCK_STUDIO) },
                onOpenSamsungCenter = { navController.navigate(VyroRoutes.SAMSUNG_EXPERIENCE) },
                onOpenWizard = { navController.navigate(VyroRoutes.WIZARD) },
                onOpenBatterySettings = viewModel::openBatteryOptimizationSettings,
                onOpenDefaultHomeSettings = viewModel::openDefaultHomeSettings,
                onBack = { navController.popBackStack() }
            )
        }
    }

    if (showQuickControlSheet) {
        QuickControlPanelSheet(
            uiState = uiState,
            onDismiss = { showQuickControlSheet = false },
            onWifiClick = viewModel::openWifiQuickPanel,
            onBluetoothClick = viewModel::openBluetoothSettings,
            onVolumePanelClick = viewModel::openVolumePanel,
            onMediaVolumeChange = viewModel::setMediaVolume,
            onRingVolumeChange = viewModel::setRingVolume,
            onBrightnessChange = viewModel::setBrightness,
            onToggleFlashlight = viewModel::toggleFlashlight,
            onToggleDarkAmoled = {
                val nextTheme = if (uiState.preferences.themeArchetype == com.vyro.home.data.model.ThemeArchetype.AMOLED) {
                    com.vyro.home.data.model.ThemeArchetype.LIGHT
                } else {
                    com.vyro.home.data.model.ThemeArchetype.AMOLED
                }
                viewModel.selectTheme(nextTheme)
            },
            onOpenFootballHub = {
                showQuickControlSheet = false
                navController.navigate(VyroRoutes.FOOTBALL_HUB)
            },
            onOpenLockStudio = {
                showQuickControlSheet = false
                navController.navigate(VyroRoutes.LOCK_STUDIO)
            },
            onOpenSettings = {
                showQuickControlSheet = false
                navController.navigate(VyroRoutes.SETTINGS)
            }
        )
    }
}
