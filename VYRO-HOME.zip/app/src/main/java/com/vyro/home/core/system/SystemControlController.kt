package com.vyro.home.core.system

import android.app.WallpaperManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.provider.Settings
import com.vyro.home.data.model.WallpaperPreset
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class SystemTelemetryState(
    val batteryPercent: Int = 100,
    val isCharging: Boolean = false,
    val batteryTempCelsius: Float = 28.0f,
    val batteryVoltageMv: Int = 4100,
    val isWifiEnabled: Boolean = true,
    val isBluetoothEnabled: Boolean = false,
    val isTorchEnabled: Boolean = false,
    val mediaVolumePercent: Int = 65,
    val ringVolumePercent: Int = 70,
    val brightnessPercent: Int = 75,
    val canWriteSystemSettings: Boolean = false
)

/**
 * Provides legitimate, official Android API integrations for VYRO Quick Control Center
 * and Wallpaper/Lock-Screen management without claiming privileged SystemUI replacement.
 */
class SystemControlController(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val wallpaperManager = WallpaperManager.getInstance(context)

    private val _telemetry = MutableStateFlow(readCurrentTelemetry())
    val telemetry: StateFlow<SystemTelemetryState> = _telemetry.asStateFlow()

    private var torchCameraId: String? = null

    init {
        try {
            torchCameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (_: Throwable) {
            torchCameraId = null
        }
    }

    fun refreshTelemetry() {
        _telemetry.value = readCurrentTelemetry()
    }

    private fun readCurrentTelemetry(): SystemTelemetryState {
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: 100
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: 100
        val batteryPct = if (level >= 0 && scale > 0) (level * 100) / scale else 100
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 280) ?: 280
        val voltage = batteryIntent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 4100) ?: 4100

        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val wifiEnabled = try { wifiManager?.isWifiEnabled ?: true } catch (_: Throwable) { true }

        val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val btEnabled = try { btManager?.adapter?.isEnabled ?: false } catch (_: Throwable) { false }

        val maxMusic = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curMusic = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val mediaPct = ((curMusic.toFloat() / maxMusic.toFloat()) * 100f).toInt().coerceIn(0, 100)

        val maxRing = audioManager.getStreamMaxVolume(AudioManager.STREAM_RING).coerceAtLeast(1)
        val curRing = audioManager.getStreamVolume(AudioManager.STREAM_RING)
        val ringPct = ((curRing.toFloat() / maxRing.toFloat()) * 100f).toInt().coerceIn(0, 100)

        val rawBrightness = try {
            Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 190)
        } catch (_: Throwable) {
            190
        }
        val brightnessPct = ((rawBrightness / 255f) * 100f).toInt().coerceIn(5, 100)
        val canWrite = Settings.System.canWrite(context)

        return SystemTelemetryState(
            batteryPercent = batteryPct,
            isCharging = isCharging,
            batteryTempCelsius = tempTenths / 10f,
            batteryVoltageMv = voltage,
            isWifiEnabled = wifiEnabled,
            isBluetoothEnabled = btEnabled,
            isTorchEnabled = _telemetry.value?.isTorchEnabled ?: false,
            mediaVolumePercent = mediaPct,
            ringVolumePercent = ringPct,
            brightnessPercent = brightnessPct,
            canWriteSystemSettings = canWrite
        )
    }

    /**
     * Opens the official Android Settings Panel floating slice for Wi-Fi / Internet connectivity.
     */
    fun openWifiQuickPanel() {
        try {
            val intent = Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Throwable) {
            val fallback = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(fallback)
        }
    }

    fun openBluetoothSettings() {
        try {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Throwable) {
        }
    }

    fun openVolumePanel() {
        try {
            val intent = Intent(Settings.Panel.ACTION_VOLUME).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Throwable) {
            audioManager.adjustVolume(AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI)
        }
    }

    fun setMediaVolumePercent(percent: Int) {
        val clamped = percent.coerceIn(0, 100)
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val target = ((clamped / 100f) * max).toInt()
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
        refreshTelemetry()
    }

    fun setRingVolumePercent(percent: Int) {
        val clamped = percent.coerceIn(0, 100)
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_RING).coerceAtLeast(1)
        val target = ((clamped / 100f) * max).toInt()
        try {
            audioManager.setStreamVolume(AudioManager.STREAM_RING, target, 0)
        } catch (_: SecurityException) {
            // Respect Do Not Disturb security policy if active
        }
        refreshTelemetry()
    }

    fun setBrightnessPercent(percent: Int): Boolean {
        val clamped = percent.coerceIn(5, 100)
        if (!Settings.System.canWrite(context)) {
            return false
        }
        return try {
            val value255 = ((clamped / 100f) * 255f).toInt().coerceIn(10, 255)
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                value255
            )
            refreshTelemetry()
            true
        } catch (_: Throwable) {
            false
        }
    }

    fun requestWriteSettingsPermission() {
        try {
            val intent = Intent(
                Settings.ACTION_MANAGE_WRITE_SETTINGS,
                Uri.parse("package:${context.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Throwable) {
        }
    }

    fun toggleFlashlight(): Boolean {
        val camId = torchCameraId ?: return false
        val nextState = !_telemetry.value.isTorchEnabled
        return try {
            cameraManager.setTorchMode(camId, nextState)
            _telemetry.value = _telemetry.value.copy(isTorchEnabled = nextState)
            true
        } catch (_: Throwable) {
            false
        }
    }

    fun openBatteryOptimizationSettings() {
        try {
            val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Throwable) {
        }
    }

    fun openDefaultHomeRoleSettings() {
        try {
            val intent = Intent(Settings.ACTION_HOME_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Throwable) {
        }
    }

    /**
     * Generates and applies a high-resolution procedural futuristic wallpaper to the Android
     * Home Screen, Lock Screen, or both using the official WallpaperManager API.
     */
    fun applyPresetWallpaperToSystem(
        preset: WallpaperPreset,
        applyToHome: Boolean = true,
        applyToLock: Boolean = false
    ): Boolean {
        return try {
            val width = 1080
            val height = 2400
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)

            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    0f, 0f, width.toFloat(), height.toFloat(),
                    intArrayOf(
                        preset.topColorHex.toInt(),
                        preset.midColorHex.toInt(),
                        preset.bottomColorHex.toInt()
                    ),
                    floatArrayOf(0f, 0.55f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

            val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    width * 0.5f,
                    height * 0.32f,
                    width * 0.65f,
                    (preset.accentGlowHex and 0x00FFFFFF or 0x66000000).toInt(),
                    0x00000000,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawCircle(width * 0.5f, height * 0.32f, width * 0.65f, glowPaint)

            var flags = 0
            if (applyToHome) flags = flags or WallpaperManager.FLAG_SYSTEM
            if (applyToLock) flags = flags or WallpaperManager.FLAG_LOCK
            if (flags == 0) flags = WallpaperManager.FLAG_SYSTEM

            wallpaperManager.setBitmap(bmp, null, true, flags)
            bmp.recycle()
            true
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Extracts primary accent color from the active system wallpaper where supported (Android 16/17).
     */
    fun extractWallpaperPrimaryColorHex(): Long? {
        return try {
            val colors = wallpaperManager.getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
            val argb = colors?.primaryColor?.toArgb() ?: return null
            (argb.toLong() and 0xFFFFFFFFL) or 0xFF000000L
        } catch (_: Throwable) {
            null
        }
    }
}
