package com.vyro.home.ui.theme

import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyro.home.data.model.IconShapeStyle
import com.vyro.home.data.model.ThemeArchetype
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun VyroHomeTheme(
    archetype: ThemeArchetype = ThemeArchetype.DARK,
    customAccentHex: Long = archetype.primaryHex,
    useWallpaperDynamicColors: Boolean = false,
    fontFamilyStyle: String = "FUTURA_SANS",
    content: @Composable () -> Unit
) {
    val context = LocalContext.current

    val primaryColor = Color(customAccentHex)
    val secondaryColor = Color(archetype.secondaryHex)
    val backgroundColor = if (archetype.isAmoled) Color(0xFF000000) else Color(archetype.backgroundHex)
    val surfaceColor = Color(archetype.surfaceHex)

    val colorScheme = when {
        useWallpaperDynamicColors && archetype.isDark -> {
            dynamicDarkColorScheme(context).copy(
                background = if (archetype.isAmoled) Color.Black else dynamicDarkColorScheme(context).background
            )
        }
        useWallpaperDynamicColors && !archetype.isDark -> {
            dynamicLightColorScheme(context)
        }
        archetype.isDark -> {
            darkColorScheme(
                primary = primaryColor,
                onPrimary = Color(0xFF040812),
                primaryContainer = primaryColor.copy(alpha = 0.22f),
                onPrimaryContainer = Color.White,
                secondary = secondaryColor,
                onSecondary = Color.White,
                secondaryContainer = secondaryColor.copy(alpha = 0.22f),
                onSecondaryContainer = Color.White,
                background = backgroundColor,
                onBackground = Color(0xFFF1F5F9),
                surface = surfaceColor,
                onSurface = Color(0xFFF8FAFC),
                surfaceVariant = surfaceColor.copy(alpha = 0.85f),
                onSurfaceVariant = Color(0xFF94A3B8)
            )
        }
        else -> {
            lightColorScheme(
                primary = primaryColor,
                onPrimary = Color.White,
                primaryContainer = primaryColor.copy(alpha = 0.16f),
                onPrimaryContainer = Color(0xFF0B1528),
                secondary = secondaryColor,
                onSecondary = Color.White,
                background = backgroundColor,
                onBackground = Color(0xFF0F172A),
                surface = surfaceColor,
                onSurface = Color(0xFF0F172A),
                surfaceVariant = Color(0xFFE2E8F0),
                onSurfaceVariant = Color(0xFF475569)
            )
        }
    }

    val chosenFontFamily = when (fontFamilyStyle) {
        "CYBER_MONO" -> FontFamily.Monospace
        "EDITORIAL_SERIF" -> FontFamily.Serif
        else -> FontFamily.SansSerif
    }

    val typography = Typography(
        headlineLarge = TextStyle(
            fontFamily = chosenFontFamily,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 30.sp,
            lineHeight = 36.sp
        ),
        headlineMedium = TextStyle(
            fontFamily = chosenFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp,
            lineHeight = 30.sp
        ),
        titleLarge = TextStyle(
            fontFamily = chosenFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 19.sp,
            lineHeight = 25.sp
        ),
        titleMedium = TextStyle(
            fontFamily = chosenFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 16.sp,
            lineHeight = 22.sp
        ),
        bodyLarge = TextStyle(
            fontFamily = chosenFontFamily,
            fontWeight = FontWeight.Normal,
            fontSize = 15.sp,
            lineHeight = 21.sp
        ),
        bodyMedium = TextStyle(
            fontFamily = chosenFontFamily,
            fontWeight = FontWeight.Normal,
            fontSize = 13.sp,
            lineHeight = 18.sp
        ),
        labelLarge = TextStyle(
            fontFamily = chosenFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            lineHeight = 17.sp
        )
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
        content = content
    )
}

fun resolveIconShape(style: IconShapeStyle): Shape {
    return when (style) {
        IconShapeStyle.SQUIRCLE_ONEUI -> RoundedCornerShape(percent = 38)
        IconShapeStyle.ADAPTIVE_CIRCLE -> RoundedCornerShape(percent = 50)
        IconShapeStyle.MINIMAL_ROUNDED -> RoundedCornerShape(percent = 26)
        IconShapeStyle.SHARP_LUXURY -> RoundedCornerShape(8.dp)
        IconShapeStyle.CYBER_HEX -> GenericShape { size, _ ->
            val cx = size.width / 2f
            val cy = size.height / 2f
            val r = minOf(cx, cy)
            for (i in 0 until 6) {
                val angleRad = Math.toRadians((60.0 * i) - 30.0)
                val x = cx + (r * cos(angleRad)).toFloat()
                val y = cy + (r * sin(angleRad)).toFloat()
                if (i == 0) moveTo(x, y) else lineTo(x, y)
            }
            close()
        }
    }
}
