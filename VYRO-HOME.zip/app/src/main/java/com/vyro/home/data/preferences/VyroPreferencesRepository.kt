package com.vyro.home.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.vyro.home.BuildConfig
import com.vyro.home.data.model.IconShapeStyle
import com.vyro.home.data.model.LauncherLayoutState
import com.vyro.home.data.model.LockScreenConfig
import com.vyro.home.data.model.ThemeArchetype
import com.vyro.home.data.model.VyroBackupPayload
import com.vyro.home.data.model.WallpaperPreset
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.vyroDataStore: DataStore<Preferences> by preferencesDataStore(name = "vyro_home_preferences")

data class UserPreferencesState(
    val onboardingCompleted: Boolean = false,
    val languageTag: String = "en",
    val themeArchetype: ThemeArchetype = ThemeArchetype.DARK,
    val customAccentHex: Long = 0xFF00E5FF,
    val useWallpaperDynamicColors: Boolean = false,
    val wallpaperPreset: WallpaperPreset = WallpaperPreset.VYRO_NEBULA,
    val iconShapeStyle: IconShapeStyle = IconShapeStyle.SQUIRCLE_ONEUI,
    val fontFamilyStyle: String = "FUTURA_SANS",
    val animationSpeedMultiplier: Float = 1.0f,
    val selectedTeams: List<String> = listOf("FCB", "RMA", "EGY"),
    val primaryTeamId: String = "FCB",
    val selectedInterests: List<String> = listOf("FOOTBALL", "PRODUCTIVITY", "GAMING"),
    val footballApiKey: String = BuildConfig.FOOTBALL_API_KEY,
    val footballApiProvider: String = BuildConfig.FOOTBALL_API_PROVIDER,
    val matchNotificationsEnabled: Boolean = true,
    val lowPowerAnimationMode: Boolean = false,
    val activeLayoutState: LauncherLayoutState = LauncherLayoutState(),
    val lockScreenConfig: LockScreenConfig = LockScreenConfig()
)

class VyroPreferencesRepository(private val context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private object Keys {
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val LANGUAGE_TAG = stringPreferencesKey("language_tag")
        val THEME_ARCHETYPE = stringPreferencesKey("theme_archetype")
        val CUSTOM_ACCENT_HEX = longPreferencesKey("custom_accent_hex")
        val USE_DYNAMIC_COLORS = booleanPreferencesKey("use_wallpaper_dynamic_colors")
        val WALLPAPER_PRESET = stringPreferencesKey("wallpaper_preset")
        val ICON_SHAPE_STYLE = stringPreferencesKey("icon_shape_style")
        val FONT_FAMILY_STYLE = stringPreferencesKey("font_family_style")
        val ANIMATION_SPEED = floatPreferencesKey("animation_speed_multiplier")
        val SELECTED_TEAMS = stringPreferencesKey("selected_teams_csv")
        val PRIMARY_TEAM_ID = stringPreferencesKey("primary_team_id")
        val SELECTED_INTERESTS = stringPreferencesKey("selected_interests_csv")
        val FOOTBALL_API_KEY = stringPreferencesKey("football_api_key")
        val FOOTBALL_API_PROVIDER = stringPreferencesKey("football_api_provider")
        val MATCH_NOTIFICATIONS = booleanPreferencesKey("match_notifications_enabled")
        val LOW_POWER_MODE = booleanPreferencesKey("low_power_animation_mode")
        val ACTIVE_LAYOUT_JSON = stringPreferencesKey("active_layout_json")
        val LOCK_SCREEN_JSON = stringPreferencesKey("lock_screen_json")
    }

    val preferencesFlow: Flow<UserPreferencesState> = context.vyroDataStore.data.map { prefs ->
        val themeId = prefs[Keys.THEME_ARCHETYPE] ?: ThemeArchetype.DARK.id
        val theme = ThemeArchetype.entries.firstOrNull { it.id == themeId } ?: ThemeArchetype.DARK

        val wpId = prefs[Keys.WALLPAPER_PRESET] ?: WallpaperPreset.VYRO_NEBULA.id
        val wp = WallpaperPreset.entries.firstOrNull { it.id == wpId } ?: WallpaperPreset.VYRO_NEBULA

        val shapeId = prefs[Keys.ICON_SHAPE_STYLE] ?: IconShapeStyle.SQUIRCLE_ONEUI.id
        val shape = IconShapeStyle.entries.firstOrNull { it.id == shapeId } ?: IconShapeStyle.SQUIRCLE_ONEUI

        val layoutState = prefs[Keys.ACTIVE_LAYOUT_JSON]?.let {
            runCatching { json.decodeFromString<LauncherLayoutState>(it) }.getOrNull()
        } ?: LauncherLayoutState()

        val lockConfig = prefs[Keys.LOCK_SCREEN_JSON]?.let {
            runCatching { json.decodeFromString<LockScreenConfig>(it) }.getOrNull()
        } ?: LockScreenConfig()

        val teamsCsv = prefs[Keys.SELECTED_TEAMS] ?: "FCB,RMA,EGY"
        val teams = teamsCsv.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            .ifEmpty { listOf("FCB", "RMA", "EGY") }

        val interestsCsv = prefs[Keys.SELECTED_INTERESTS] ?: "FOOTBALL,PRODUCTIVITY,GAMING"
        val interests = interestsCsv.split(",").map { it.trim() }.filter { it.isNotEmpty() }

        val storedApiKey = prefs[Keys.FOOTBALL_API_KEY]
        val resolvedApiKey = if (!storedApiKey.isNullOrBlank()) storedApiKey else BuildConfig.FOOTBALL_API_KEY

        UserPreferencesState(
            onboardingCompleted = prefs[Keys.ONBOARDING_COMPLETED] ?: false,
            languageTag = prefs[Keys.LANGUAGE_TAG] ?: "en",
            themeArchetype = theme,
            customAccentHex = prefs[Keys.CUSTOM_ACCENT_HEX] ?: theme.primaryHex,
            useWallpaperDynamicColors = prefs[Keys.USE_DYNAMIC_COLORS] ?: false,
            wallpaperPreset = wp,
            iconShapeStyle = shape,
            fontFamilyStyle = prefs[Keys.FONT_FAMILY_STYLE] ?: "FUTURA_SANS",
            animationSpeedMultiplier = prefs[Keys.ANIMATION_SPEED] ?: 1.0f,
            selectedTeams = teams,
            primaryTeamId = prefs[Keys.PRIMARY_TEAM_ID] ?: teams.first(),
            selectedInterests = interests,
            footballApiKey = resolvedApiKey,
            footballApiProvider = prefs[Keys.FOOTBALL_API_PROVIDER] ?: BuildConfig.FOOTBALL_API_PROVIDER,
            matchNotificationsEnabled = prefs[Keys.MATCH_NOTIFICATIONS] ?: true,
            lowPowerAnimationMode = prefs[Keys.LOW_POWER_MODE] ?: false,
            activeLayoutState = layoutState,
            lockScreenConfig = lockConfig
        )
    }

    suspend fun setLanguageTag(tag: String) {
        context.vyroDataStore.edit { it[Keys.LANGUAGE_TAG] = tag }
    }

    suspend fun updateTheme(
        archetype: ThemeArchetype,
        customAccentHex: Long = archetype.primaryHex,
        useDynamicColors: Boolean = false
    ) {
        context.vyroDataStore.edit {
            it[Keys.THEME_ARCHETYPE] = archetype.id
            it[Keys.CUSTOM_ACCENT_HEX] = customAccentHex
            it[Keys.USE_DYNAMIC_COLORS] = useDynamicColors
        }
    }

    suspend fun updateWallpaperAndIcons(
        wallpaper: WallpaperPreset,
        iconShape: IconShapeStyle,
        fontStyle: String,
        animSpeed: Float
    ) {
        context.vyroDataStore.edit {
            it[Keys.WALLPAPER_PRESET] = wallpaper.id
            it[Keys.ICON_SHAPE_STYLE] = iconShape.id
            it[Keys.FONT_FAMILY_STYLE] = fontStyle
            it[Keys.ANIMATION_SPEED] = animSpeed
        }
    }

    suspend fun saveAppliedLayout(
        layoutState: LauncherLayoutState,
        markOnboardingComplete: Boolean = true
    ) {
        val encoded = json.encodeToString(layoutState)
        context.vyroDataStore.edit {
            it[Keys.ACTIVE_LAYOUT_JSON] = encoded
            if (markOnboardingComplete) {
                it[Keys.ONBOARDING_COMPLETED] = true
            }
        }
    }

    suspend fun updateInterestsAndTeams(
        interests: List<String>,
        teams: List<String>,
        primaryTeamId: String
    ) {
        context.vyroDataStore.edit {
            it[Keys.SELECTED_INTERESTS] = interests.joinToString(",")
            it[Keys.SELECTED_TEAMS] = teams.joinToString(",")
            it[Keys.PRIMARY_TEAM_ID] = primaryTeamId
        }
    }

    suspend fun updateFootballApiConfig(apiKey: String, provider: String, notificationsEnabled: Boolean) {
        context.vyroDataStore.edit {
            it[Keys.FOOTBALL_API_KEY] = apiKey.trim()
            it[Keys.FOOTBALL_API_PROVIDER] = provider.trim()
            it[Keys.MATCH_NOTIFICATIONS] = notificationsEnabled
        }
    }

    suspend fun updateLockScreenConfig(config: LockScreenConfig) {
        val encoded = json.encodeToString(config)
        context.vyroDataStore.edit {
            it[Keys.LOCK_SCREEN_JSON] = encoded
        }
    }

    suspend fun setLowPowerMode(enabled: Boolean) {
        context.vyroDataStore.edit {
            it[Keys.LOW_POWER_MODE] = enabled
        }
    }

    suspend fun importBackupPayload(payload: VyroBackupPayload) {
        context.vyroDataStore.edit {
            it[Keys.ONBOARDING_COMPLETED] = true
            it[Keys.LANGUAGE_TAG] = payload.languageTag
            it[Keys.THEME_ARCHETYPE] = payload.themeArchetype.id
            it[Keys.CUSTOM_ACCENT_HEX] = payload.customAccentHex
            it[Keys.USE_DYNAMIC_COLORS] = payload.useWallpaperDynamicColors
            it[Keys.WALLPAPER_PRESET] = payload.wallpaperPreset.id
            it[Keys.ICON_SHAPE_STYLE] = payload.iconShapeStyle.id
            it[Keys.FONT_FAMILY_STYLE] = payload.fontFamilyStyle
            it[Keys.ANIMATION_SPEED] = payload.animationSpeedMultiplier
            it[Keys.SELECTED_TEAMS] = payload.selectedTeams.joinToString(",")
            it[Keys.PRIMARY_TEAM_ID] = payload.primaryTeamId
            it[Keys.SELECTED_INTERESTS] = payload.selectedInterests.joinToString(",")
            it[Keys.ACTIVE_LAYOUT_JSON] = json.encodeToString(payload.layoutState)
            it[Keys.LOCK_SCREEN_JSON] = json.encodeToString(payload.lockScreenConfig)
        }
    }
}
