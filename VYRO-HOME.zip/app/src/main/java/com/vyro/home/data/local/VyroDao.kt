package com.vyro.home.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface VyroDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLayoutSnapshot(snapshot: LayoutSnapshotEntity): Long

    @Query("SELECT * FROM layout_snapshots ORDER BY createdAtEpochMs DESC LIMIT 25")
    fun observeLayoutSnapshots(): Flow<List<LayoutSnapshotEntity>>

    @Query("SELECT * FROM layout_snapshots ORDER BY createdAtEpochMs DESC LIMIT 2")
    suspend fun getLatestTwoSnapshots(): List<LayoutSnapshotEntity>

    @Query("DELETE FROM layout_snapshots WHERE id = :id")
    suspend fun deleteSnapshotById(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertThemeProfile(profile: SavedThemeProfileEntity)

    @Query("SELECT * FROM saved_theme_profiles ORDER BY createdAtEpochMs DESC")
    fun observeSavedThemeProfiles(): Flow<List<SavedThemeProfileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCachedMatches(matches: List<CachedFootballMatchEntity>)

    @Query("SELECT * FROM cached_football_matches WHERE teamId = :teamId ORDER BY utcDate ASC")
    suspend fun getCachedMatchesForTeam(teamId: String): List<CachedFootballMatchEntity>
}
