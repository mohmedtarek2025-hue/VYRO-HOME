package com.vyro.home.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyro.home.data.model.IconShapeStyle
import com.vyro.home.ui.viewmodel.VyroUiState

@Composable
fun SamsungExperienceScreen(
    uiState: VyroUiState,
    onToggleReachMode: (Boolean) -> Unit,
    onSelectIconShape: (IconShapeStyle) -> Unit,
    onApplyOneUiPreset: () -> Unit,
    onBack: () -> Unit
) {
    val isAr = uiState.isArabic
    val report = uiState.deviceReport
    val layout = uiState.preferences.activeLayoutState

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = if (isAr) "تخصيص سامسونج One UI والشركات المصنعة" else "SAMSUNG ONE UI & OEM ADAPTATION",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Runtime Hardware & One UI Detection Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF111C35))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = if (isAr) "تقرير فحص الجهاز الفوري (Runtime Detection)" else "Runtime Device & One UI Inspection",
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text("• Manufacturer / Brand: ${report.manufacturer} (${report.brand})", color = Color.White, fontSize = 13.sp)
                        Text("• Model / Device: ${report.model} (${report.deviceCode})", color = Color.White, fontSize = 13.sp)
                        Text("• Android OS: ${report.androidGenerationLabel}", color = Color.White, fontSize = 13.sp)
                        Text("• Samsung Device Detected: ${if (report.isSamsungDevice) "YES" else "NO"}", color = Color.White, fontSize = 13.sp)
                        Text("• One UI Environment: ${report.oneUiVersionLabel}", color = Color.White, fontSize = 13.sp)
                        Text(
                            text = "• One UI 9.0 Verified Status: ${if (report.isOneUi9Detected) "DETECTED (One UI 9.0)" else "UNAVAILABLE ON THIS FIRMWARE"}",
                            color = if (report.isOneUi9Detected) Color(0xFF10B981) else Color(0xFFF59E0B),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isAr) report.oneUi9DisclosureAr else report.oneUi9DisclosureEn,
                            fontSize = 12.sp,
                            color = Color(0xFFCBD5E1)
                        )
                    }
                }
            }

            // One UI Ergonomic Reach Mode
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isAr) "وضع الوصول بيد واحدة (One UI Viewing Area)" else "Samsung One UI Ergonomic Thumb-Reach Header",
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isAr) "يضع الساعة في الجزء العلوي ويدفع المجلدات والتطبيقات لمتناول الإبهام." else "Allocates an upper viewing header so folders and apps rest naturally within one-handed thumb reach.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = layout.oneUiReachEnabled,
                                onCheckedChange = onToggleReachMode
                            )
                        }
                    }
                }
            }

            // Samsung Squircle Icon Geometry
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isAr) "هندسة أيقونات سامسونج One UI Squircle" else "One UI Squircle Icon Geometry",
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IconShapeStyle.entries.take(3).forEach { shape ->
                                FilterChip(
                                    selected = uiState.preferences.iconShapeStyle == shape,
                                    onClick = { onSelectIconShape(shape) },
                                    label = { Text(if (isAr) shape.labelAr else shape.labelEn, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
            }

            // Honest Good Lock / Theme Park / Home Up Disclosure (Requirement 8)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = if (isAr) "شفافية واجهات سامسونج (Good Lock / Theme Park / Home Up)" else "Samsung Ecosystem & Privileged API Transparency",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = if (isAr) {
                                "لا يدّعي VYRO HOME امتلاك صلاحيات النظام الخاصة بتطبيقات Good Lock أو Theme Park أو Home Up غير الموثقة. يوفر محرك VYRO بدائل أصلية متكاملة داخل اللانشر نفسه."
                            } else {
                                "VYRO HOME never pretends to access private Samsung Good Lock, Theme Park, or Home Up system hooks. Instead, it provides its own built-in theme, squircle icon, and grid engine using public Android 16/17 APIs."
                            },
                            fontSize = 12.sp,
                            color = Color(0xFFCBD5E1)
                        )
                        Text(
                            text = "• Good Lock Package Installed: ${if (report.hasGoodLockInstalled) "Installed" else "Not Installed"}",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                        Text(
                            text = "• Theme Park Package Installed: ${if (report.hasThemeParkInstalled) "Installed" else "Not Installed"}",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                        Text(
                            text = "• Home Up Package Installed: ${if (report.hasHomeUpInstalled) "Installed" else "Not Installed"}",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
            }

            item {
                Button(
                    onClick = onApplyOneUiPreset,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (isAr) "تطبيق الملف البصري الكامل لـ Samsung One UI" else "Apply Complete Samsung One UI Visual Preset")
                }
            }
        }
    }
}
