package com.vyro.home.data.model

import kotlinx.serialization.Serializable

@Serializable
enum class ThemeArchetype(
    val id: String,
    val titleEn: String,
    val titleAr: String,
    val primaryHex: Long,
    val secondaryHex: Long,
    val backgroundHex: Long,
    val surfaceHex: Long,
    val isDark: Boolean,
    val isAmoled: Boolean = false
) {
    DARK("dark", "Dark Futura", "الوضع الداكن المستقبلي", 0xFF00E5FF, 0xFF7C4DFF, 0xFF0B0F19, 0xFF151C2C, true),
    LIGHT("light", "Solar Light", "الوضع النهاري المشرق", 0xFF0066CC, 0xFF00897B, 0xFFF5F8FC, 0xFFFFFFFF, false),
    AMOLED("amoled", "Obsidian AMOLED", "أسود أموليد عميق", 0xFF00F5D4, 0xFF7B2CBF, 0xFF000000, 0xFF0A0A0E, true, true),
    CALM("calm", "Zen Mist Calm", "هدوء الضباب", 0xFF64B5F6, 0xFF81C784, 0xFF101820, 0xFF1A2634, true),
    NEON("neon", "Cyber Neon Pulse", "نبض النيون السيبراني", 0xFFFF007F, 0xFF00F0FF, 0xFF090414, 0xFF160B2E, true),
    MINIMAL("minimal", "Monolith Minimal", "بساطة أحادية", 0xFFE0E0E0, 0xFF9E9E9E, 0xFF121212, 0xFF1E1E1E, true),
    LUXURY("luxury", "Imperial Gold Luxury", "فخامة الذهب الإمبراطوري", 0xFFD4AF37, 0xFFC5A059, 0xFF0D0B08, 0xFF1A1610, true),
    GAMING("gaming", "Overclock RGB Gaming", "ألعاب آر جي بي فائقة", 0xFF00FF66, 0xFFFF2A54, 0xFF070A0E, 0xFF111822, true),
    FOOTBALL("football", "Stadium Matchday", "أجواء ملعب كرة القدم", 0xFF10B981, 0xFFF59E0B, 0xFF071710, 0xFF0E291E, true),
    NATURE("nature", "Oasis Emerald Nature", "طبيعة الواحة الزمردية", 0xFF34D399, 0xFFA7F3D0, 0xFF091914, 0xFF122B23, true)
}

@Serializable
enum class IconShapeStyle(val id: String, val labelEn: String, val labelAr: String, val cornerPercent: Int) {
    SQUIRCLE_ONEUI("squircle_oneui", "Samsung One UI Squircle", "منحني سامسونج One UI", 38),
    ADAPTIVE_CIRCLE("circle", "Orbital Circle", "دائري مداري", 50),
    CYBER_HEX("hexagon", "Cyber Bevel Glass", "سداسي زجاجي", 18),
    MINIMAL_ROUNDED("rounded", "Minimal Soft Square", "مربع ناعم بسيط", 26),
    SHARP_LUXURY("sharp", "Precision Diamond Cut", "حواف حادة فاخرة", 10)
}

@Serializable
enum class WallpaperPreset(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val topColorHex: Long,
    val midColorHex: Long,
    val bottomColorHex: Long,
    val accentGlowHex: Long
) {
    VYRO_NEBULA("vyro_nebula", "VYRO Quantum Nebula", "سديم فايرو الكمومي", 0xFF060B19, 0xFF111C38, 0xFF040710, 0xFF00E5FF),
    OBSIDIAN_VOID("obsidian_void", "True AMOLED Pitch Void", "فراغ أموليد النقي", 0xFF000000, 0xFF050508, 0xFF000000, 0xFF00F5D4),
    BLAUGRANA_ARENA("blaugrana_arena", "Camp Nou Blaugrana", "بلوغرانا برشلونة", 0xFF001C3D, 0xFF4A0E2E, 0xFF090D16, 0xFFEDBB00),
    BERNABEU_ROYAL("bernabeu_royal", "Royal Bernabéu Gold", "الملكي ريال مدريد", 0xFF0A1128, 0xFF1C2541, 0xFF070B19, 0xFFFEBE10),
    NILE_PHARAOH("nile_pharaoh", "Egypt Pharaoh Crimson", "الفراعنة منتخب مصر", 0xFF2B090C, 0xFF140708, 0xFF08080A, 0xFFD4AF37),
    SAMSUNG_HORIZON("samsung_horizon", "One UI Galaxy Horizon", "أفق جالاكسي One UI", 0xFF091E3A, 0xFF1B3B6F, 0xFF061121, 0xFF38BDF8),
    EMERALD_OASIS("emerald_oasis", "Sinai Emerald Oasis", "واحة الزمرد الهادئة", 0xFF051F18, 0xFF0B3B2D, 0xFF03120E, 0xFF34D399)
}

@Serializable
enum class LayoutPresetType(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val descEn: String,
    val descAr: String,
    val columns: Int,
    val rows: Int,
    val dockCount: Int,
    val oneUiReachHeader: Boolean
) {
    ONE_UI_ERGONOMIC(
        "one_ui_ergonomic",
        "Samsung One UI Reach",
        "تخطيط سامسونج المريح لليد الواحدة",
        "Upper viewing header with one-handed thumb-reach smart folders and 4x5 grid.",
        "منطقة علوية للعرض مع مجلدات ذكية قريبة من الإبهام وشبكة 4×5.",
        4, 5, 4, true
    ),
    MINIMAL_ZEN(
        "minimal_zen",
        "Minimal Clean Zen",
        "التخطيط البسيط الهادئ",
        "Uncluttered workspace with essential favorites and unified smart folders.",
        "مساحة عمل نظيفة تضم التطبيقات الأساسية والمجلدات الذكية الموحدة.",
        4, 5, 4, false
    ),
    POWER_DENSE(
        "power_dense",
        "Power Matrix 5x6",
        "شبكة المحترفين الكثيفة 5×6",
        "High-density 5x6 layout with full telemetry widgets and 5-icon dock.",
        "شبكة عالية الكثافة 5×6 مع ودجات النظام الكاملة وشريط سفلي لـ 5 تطبيقات.",
        5, 6, 5, false
    ),
    FOOTBALL_COMMAND(
        "football_command",
        "Football Matchday Center",
        "مركز يوم المباراة الكروي",
        "Dedicated Football Hub live widget front-and-center with sports smart folder.",
        "ودجت مركز كرة القدم المباشر في الواجهة مع مجلد التطبيقات الرياضية.",
        4, 5, 5, false
    ),
    GAMING_ARENA(
        "gaming_arena",
        "Gaming Command Deck",
        "منصة قيادة الألعاب",
        "Performance telemetry widget, instant Game Folder, and neon-accented dock.",
        "ودجت مراقبة الأداء ومجلد الألعاب الفوري مع شريط سفلي مضيء.",
        4, 6, 5, false
    )
}

@Serializable
enum class AppCategory(val id: String, val titleEn: String, val titleAr: String) {
    SOCIAL("social", "Social & Communication", "التواصل الاجتماعي"),
    GAMES("games", "Gaming Arena", "الألعاب"),
    PRODUCTIVITY("productivity", "Productivity & Work", "الإنتاجية والعمل"),
    MEDIA("media", "Media & Entertainment", "الوسائط والترفيه"),
    FOOTBALL_SPORTS("football_sports", "Football & Sports", "كرة القدم والرياضة"),
    FINANCE("finance", "Finance & Banking", "المال والبنوك"),
    UTILITIES("utilities", "Tools & Utilities", "الأدوات والنظام"),
    OTHER("other", "Essential Apps", "تطبيقات متنوعة")
}

@Serializable
data class InstalledAppInfo(
    val packageName: String,
    val activityName: String,
    val label: String,
    val category: AppCategory,
    val isSystemApp: Boolean,
    val firstInstallTime: Long = 0L
)

@Serializable
data class SmartFolderModel(
    val id: String,
    val titleEn: String,
    val titleAr: String,
    val category: AppCategory,
    val appPackages: List<String>,
    val accentHex: Long = 0xFF00E5FF
)

@Serializable
enum class WidgetType(val id: String, val titleEn: String, val titleAr: String) {
    CLOCK_WEATHER("clock_weather", "VYRO Orbital Clock & Weather", "ساعة فايرو والطقس"),
    FOOTBALL_LIVE("football_live", "Football Matchday Hub Widget", "ودجت مركز كرة القدم"),
    QUICK_CONTROL_BAR("quick_control", "One UI Quick Control Strip", "شريط التحكم السريع"),
    DEVICE_TELEMETRY("device_telemetry", "Android 16/17 System Telemetry", "مؤشرات النظام والبطارية")
}

@Serializable
enum class ClockStylePreset(val id: String, val nameEn: String, val nameAr: String) {
    ONEUI_STACKED("oneui_stacked", "Samsung One UI Stacked", "ساعة سامسونج الرأسية"),
    CYBER_SPLIT("cyber_split", "VYRO Neon Cyber Split", "ساعة النيون الرقمية"),
    ARABIC_MODERN("arabic_modern", "Modern Arabic Eastern Numerals", "الأرقام العربية المشرقية"),
    MINIMAL_HORIZON("minimal_horizon", "Minimal Horizon Line", "الخط الأفقي البسيط"),
    CHRONO_RING("chrono_ring", "Orbital Chronograph Ring", "الحلقة المدارية")
}

@Serializable
enum class LockNotificationPrivacy(val id: String, val labelEn: String, val labelAr: String) {
    SHOW_ALL("show_all", "Show Full Notification Content", "إظهار محتوى الإشعارات بالكامل"),
    HIDE_SENSITIVE("hide_sensitive", "Hide Sensitive Content on Lock Screen", "إخفاء المحتوى الحساس على شاشة القفل"),
    ICONS_ONLY("icons_only", "Show App Icons & Count Badge Only", "إظهار أيقونات التطبيقات والعدد فقط")
}

@Serializable
data class LockScreenConfig(
    val clockStyle: ClockStylePreset = ClockStylePreset.ONEUI_STACKED,
    val showDate: Boolean = true,
    val showWeather: Boolean = true,
    val showFootballWidget: Boolean = true,
    val wallpaperPreset: WallpaperPreset = WallpaperPreset.VYRO_NEBULA,
    val accentColorHex: Long = 0xFF00E5FF,
    val leftShortcut: String = "FLASHLIGHT",
    val rightShortcut: String = "FOOTBALL_HUB",
    val notificationPrivacy: LockNotificationPrivacy = LockNotificationPrivacy.HIDE_SENSITIVE
)

@Serializable
data class LauncherLayoutState(
    val timestamp: Long = System.currentTimeMillis(),
    val description: String = "Auto-Generated VYRO Layout",
    val presetType: LayoutPresetType = LayoutPresetType.ONE_UI_ERGONOMIC,
    val gridColumns: Int = 4,
    val gridRows: Int = 5,
    val dockCount: Int = 4,
    val iconScale: Float = 1.0f,
    val oneUiReachEnabled: Boolean = false,
    val activeWidgets: List<WidgetType> = listOf(WidgetType.CLOCK_WEATHER, WidgetType.FOOTBALL_LIVE),
    val smartFolders: List<SmartFolderModel> = emptyList(),
    val favoritePackages: List<String> = emptyList(),
    val dockPackages: List<String> = emptyList()
)

@Serializable
data class FootballTeamProfile(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val shortCode: String,
    val leagueEn: String,
    val leagueAr: String,
    val stadiumEn: String,
    val stadiumAr: String,
    val primaryColorHex: Long,
    val secondaryColorHex: Long,
    val footballDataOrgId: Int,
    val apiFootballId: Int,
    val competitionCode: String
)

@Serializable
data class FootballMatchItem(
    val id: String,
    val competitionName: String,
    val homeTeamEn: String,
    val homeTeamAr: String,
    val awayTeamEn: String,
    val awayTeamAr: String,
    val homeScore: Int?,
    val awayScore: Int?,
    val status: String, // "LIVE", "TIMED", "SCHEDULED", "FINISHED", "API_KEY_REQUIRED"
    val utcDate: String,
    val venue: String,
    val isVerifiedLiveApi: Boolean
)

@Serializable
data class StandingRow(
    val position: Int,
    val teamNameEn: String,
    val teamNameAr: String,
    val played: Int,
    val won: Int,
    val drawn: Int,
    val lost: Int,
    val goalDifference: Int,
    val points: Int
)

@Serializable
data class FootballNewsItem(
    val id: String,
    val teamId: String,
    val titleEn: String,
    val titleAr: String,
    val summaryEn: String,
    val summaryAr: String,
    val sourceName: String,
    val sourceUrl: String,
    val publishedLabel: String
)

@Serializable
data class VyroBackupPayload(
    val backupVersion: Int = 1,
    val exportedAtEpochMs: Long = System.currentTimeMillis(),
    val appVersion: String = "1.0.0-FUTURA",
    val languageTag: String = "en",
    val themeArchetype: ThemeArchetype = ThemeArchetype.DARK,
    val customAccentHex: Long = 0xFF00E5FF,
    val useWallpaperDynamicColors: Boolean = false,
    val wallpaperPreset: WallpaperPreset = WallpaperPreset.VYRO_NEBULA,
    val iconShapeStyle: IconShapeStyle = IconShapeStyle.SQUIRCLE_ONEUI,
    val fontFamilyStyle: String = "FUTURA_SANS",
    val animationSpeedMultiplier: Float = 1.0f,
    val selectedTeams: List<String> = listOf("FCB", "RMA", "EGY"),
    val primaryTeamId: String = "FCB",
    val selectedInterests: List<String> = listOf("FOOTBALL", "PRODUCTIVITY", "GAMING"),
    val layoutState: LauncherLayoutState = LauncherLayoutState(),
    val lockScreenConfig: LockScreenConfig = LockScreenConfig()
)
