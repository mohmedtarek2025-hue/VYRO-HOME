package com.vyro.home.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "layout_snapshots")
data class LayoutSnapshotEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAtEpochMs: Long,
    val label: String,
    val presetId: String,
    val layoutJson: String
)

@Entity(tableName = "saved_theme_profiles")
data class SavedThemeProfileEntity(
    @PrimaryKey val profileId: String,
    val name: String,
    val themeArchetypeId: String,
    val accentHex: Long,
    val wallpaperId: String,
    val iconShapeId: String,
    val createdAtEpochMs: Long
)

@Entity(tableName = "cached_football_matches")
data class CachedFootballMatchEntity(
    @PrimaryKey val matchId: String,
    val teamId: String,
    val competitionName: String,
    val homeTeamEn: String,
    val homeTeamAr: String,
    val awayTeamEn: String,
    val awayTeamAr: String,
    val homeScore: Int?,
    val awayScore: Int?,
    val status: String,
    val utcDate: String,
    val venue: String,
    val updatedAtEpochMs: Long
)
