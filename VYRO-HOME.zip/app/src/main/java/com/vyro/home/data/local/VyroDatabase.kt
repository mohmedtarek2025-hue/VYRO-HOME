package com.vyro.home.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        LayoutSnapshotEntity::class,
        SavedThemeProfileEntity::class,
        CachedFootballMatchEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class VyroDatabase : RoomDatabase() {
    abstract fun vyroDao(): VyroDao

    companion object {
        @Volatile
        private var INSTANCE: VyroDatabase? = null

        fun getInstance(context: Context): VyroDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    VyroDatabase::class.java,
                    "vyro_home_launcher.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
