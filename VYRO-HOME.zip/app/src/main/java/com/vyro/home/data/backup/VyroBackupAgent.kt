package com.vyro.home.data.backup

import android.app.backup.BackupAgentHelper
import android.app.backup.FileBackupHelper

/**
 * Android BackupAgentHelper integration for VYRO HOME configuration persistence.
 * Works alongside Android 12–17 data_extraction_rules.xml for cloud & device-to-device transfer.
 */
class VyroBackupAgent : BackupAgentHelper() {
    override fun onCreate() {
        super.onCreate()
        val datastoreHelper = FileBackupHelper(this, "datastore/vyro_home_preferences.preferences_pb")
        addHelper("vyro_datastore_backup", datastoreHelper)
    }
}
