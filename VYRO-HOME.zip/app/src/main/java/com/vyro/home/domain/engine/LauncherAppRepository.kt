package com.vyro.home.domain.engine

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.os.Process
import com.vyro.home.data.model.AppCategory
import com.vyro.home.data.model.InstalledAppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/**
 * Queries real installed launchable applications using the official Android LauncherApps service.
 * Strictly read-only with respect to user apps: never deletes, disables, or alters installed apps.
 */
class LauncherAppRepository(private val context: Context) {

    private val launcherApps = context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
    private val iconCache = ConcurrentHashMap<String, Drawable>()

    suspend fun loadInstalledApps(): List<InstalledAppInfo> = withContext(Dispatchers.IO) {
        val userHandle = Process.myUserHandle()
        val activityList = try {
            launcherApps.getActivityList(null, userHandle)
        } catch (_: Throwable) {
            emptyList()
        }

        val myPkg = context.packageName
        val mapped = activityList
            .filter { it.applicationInfo.packageName != myPkg }
            .map { info ->
                val pkg = info.applicationInfo.packageName
                val act = info.componentName.className
                val label = info.label?.toString()?.takeIf { it.isNotBlank() } ?: pkg
                val isSys = (info.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val cat = classifyApp(pkg, label, info.applicationInfo.category)
                try {
                    iconCache[pkg] = info.getBadgedIcon(0)
                } catch (_: Throwable) {
                }
                InstalledAppInfo(
                    packageName = pkg,
                    activityName = act,
                    label = label,
                    category = cat,
                    isSystemApp = isSys,
                    firstInstallTime = info.firstInstallTime
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }

        mapped.ifEmpty { provideFallbackCatalogForPreview() }
    }

    fun getCachedIcon(packageName: String): Drawable? = iconCache[packageName]

    fun launchApp(app: InstalledAppInfo): Boolean {
        return try {
            val component = ComponentName(app.packageName, app.activityName)
            launcherApps.startMainActivity(component, Process.myUserHandle(), Rect(), null)
            true
        } catch (_: Throwable) {
            try {
                val launchIntent = context.packageManager.getLaunchIntentForPackage(app.packageName)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    true
                } else {
                    false
                }
            } catch (_: Throwable) {
                false
            }
        }
    }

    fun openAppSystemInfo(packageName: String) {
        try {
            val activities = launcherApps.getActivityList(packageName, Process.myUserHandle())
            val first = activities.firstOrNull()
            if (first != null) {
                launcherApps.startAppDetailsActivity(first.componentName, Process.myUserHandle(), Rect(), null)
            }
        } catch (_: Throwable) {
        }
    }

    fun classifyApp(packageName: String, label: String, androidCategory: Int): AppCategory {
        val p = packageName.lowercase()
        val l = label.lowercase()

        if (p.contains("fifa") || p.contains("eafc") || p.contains("fotmob") ||
            p.contains("sofascore") || p.contains("livescore") || p.contains("onefootball") ||
            p.contains("barcelona") || p.contains("realmadrid") || p.contains("kooora") ||
            l.contains("football") || l.contains("soccer") || l.contains("كورة")
        ) {
            return AppCategory.FOOTBALL_SPORTS
        }

        return when (androidCategory) {
            ApplicationInfo.CATEGORY_GAME -> AppCategory.GAMES
            ApplicationInfo.CATEGORY_SOCIAL -> AppCategory.SOCIAL
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> AppCategory.PRODUCTIVITY
            ApplicationInfo.CATEGORY_VIDEO,
            ApplicationInfo.CATEGORY_AUDIO,
            ApplicationInfo.CATEGORY_IMAGE -> AppCategory.MEDIA
            else -> when {
                p.contains("whatsapp") || p.contains("telegram") || p.contains("instagram") ||
                        p.contains("facebook") || p.contains("messenger") || p.contains("twitter") ||
                        p.contains("tiktok") || p.contains("snapchat") || p.contains("dialer") ||
                        p.contains("messaging") || p.contains("contacts") -> AppCategory.SOCIAL

                p.contains("game") || p.contains("pubg") || p.contains("genshin") ||
                        p.contains("brawl") || p.contains("roblox") || p.contains("minecraft") -> AppCategory.GAMES

                p.contains("docs") || p.contains("sheets") || p.contains("calendar") ||
                        p.contains("notes") || p.contains("gmail") || p.contains("email") ||
                        p.contains("office") || p.contains("slack") || p.contains("notion") -> AppCategory.PRODUCTIVITY

                p.contains("youtube") || p.contains("spotify") || p.contains("netflix") ||
                        p.contains("gallery") || p.contains("camera") || p.contains("music") ||
                        p.contains("photos") || p.contains("shahid") || p.contains("watchit") -> AppCategory.MEDIA

                p.contains("bank") || p.contains("wallet") || p.contains("pay") ||
                        p.contains("fawry") || p.contains("instapay") || p.contains("finance") -> AppCategory.FINANCE

                p.contains("settings") || p.contains("calculator") || p.contains("clock") ||
                        p.contains("files") || p.contains("vending") || p.contains("chrome") ||
                        p.contains("browser") || p.contains("maps") -> AppCategory.UTILITIES

                else -> AppCategory.OTHER
            }
        }
    }

    private fun provideFallbackCatalogForPreview(): List<InstalledAppInfo> = listOf(
        InstalledAppInfo("com.android.dialer", "com.android.dialer.MainActivity", "Phone", AppCategory.SOCIAL, true),
        InstalledAppInfo("com.google.android.apps.messaging", ".ui.ConversationListActivity", "Messages", AppCategory.SOCIAL, true),
        InstalledAppInfo("com.android.chrome", "com.google.android.apps.chrome.Main", "Chrome", AppCategory.UTILITIES, true),
        InstalledAppInfo("com.android.camera2", "com.android.camera.CameraActivity", "Camera", AppCategory.MEDIA, true),
        InstalledAppInfo("com.android.settings", "com.android.settings.Settings", "Settings", AppCategory.UTILITIES, true),
        InstalledAppInfo("com.google.android.youtube", ".HomeActivity", "YouTube", AppCategory.MEDIA, false),
        InstalledAppInfo("com.whatsapp", "com.whatsapp.Main", "WhatsApp", AppCategory.SOCIAL, false),
        InstalledAppInfo("com.google.android.gm", ".ConversationListActivityGmail", "Gmail", AppCategory.PRODUCTIVITY, false),
        InstalledAppInfo("com.google.android.calendar", ".AllInOneActivity", "Calendar", AppCategory.PRODUCTIVITY, false),
        InstalledAppInfo("com.mobilefootie.wc2010", ".gui.HomeActivity", "FotMob Football", AppCategory.FOOTBALL_SPORTS, false),
        InstalledAppInfo("com.ea.gp.fifamobile", ".MainActivity", "EA SPORTS FC", AppCategory.GAMES, false),
        InstalledAppInfo("com.spotify.music", ".MainActivity", "Spotify", AppCategory.MEDIA, false)
    )
}
