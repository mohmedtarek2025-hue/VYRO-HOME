package com.vyro.home.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyro.home.domain.football.FootballSyncStatus
import com.vyro.home.ui.viewmodel.VyroUiState

@Composable
fun FootballHubScreen(
    uiState: VyroUiState,
    onSelectTeam: (String, Boolean) -> Unit,
    onRefreshHub: () -> Unit,
    onSaveApiConfig: (String, String, Boolean) -> Unit,
    onSendTestNotification: () -> Unit,
    onBack: () -> Unit
) {
    val isAr = uiState.isArabic
    val prefs = uiState.preferences
    val snapshot = uiState.footballSnapshot

    var selectedTab by remember { mutableIntStateOf(0) }
    var showApiKeyDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
            .padding(16.dp)
    ) {
        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = if (isAr) "مركز كرة القدم VYRO" else "VYRO FOOTBALL HUB",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold
            )
            Row {
                IconButton(onClick = { showApiKeyDialog = true }) {
                    Icon(Icons.Default.Key, contentDescription = "API Key Configuration")
                }
                IconButton(onClick = onRefreshHub) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Team Selector Strip (FC Barcelona, Real Madrid, Egypt National Team + Additional Clubs)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(uiState.supportedTeams) { team ->
                val isSelected = prefs.primaryTeamId == team.id
                Card(
                    modifier = Modifier
                        .clickable { onSelectTeam(team.id, false) }
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) Color(team.primaryColorHex) else Color(0x33FFFFFF),
                            shape = RoundedCornerShape(16.dp)
                        ),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) Color(team.primaryColorHex).copy(alpha = 0.25f)
                        else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(Color(team.primaryColorHex))
                        )
                        Text(
                            text = if (isAr) team.nameAr else team.nameEn,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Active Team Banner & Actions
        snapshot?.team?.let { team ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(team.primaryColorHex).copy(alpha = 0.22f)
                )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (isAr) team.nameAr else team.nameEn,
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color.White
                    )
                    Text(
                        text = "${if (isAr) team.leagueAr else team.leagueEn} • ${if (isAr) team.stadiumAr else team.stadiumEn}",
                        fontSize = 12.sp,
                        color = Color(0xFFCBD5E1)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { onSelectTeam(team.id, true) }
                        ) {
                            Icon(Icons.Default.Palette, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.size(6.dp))
                            Text(if (isAr) "تطبيق ثيم الفريق" else "Apply Club Theme", fontSize = 12.sp)
                        }
                        OutlinedButton(
                            onClick = onSendTestNotification
                        ) {
                            Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.size(6.dp))
                            Text(if (isAr) "إشعار المباراة" else "Match Alert", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // API Transparency Banner (Never fakes live scores)
        when (val status = snapshot?.syncStatus) {
            is FootballSyncStatus.ApiKeyRequired -> {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showApiKeyDialog = true },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF3B2110)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (isAr) status.messageAr else status.messageEn,
                            fontSize = 12.sp,
                            color = Color(0xFFFDE68A)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isAr) "اضغط هنا لإدخال مفتاح API" else "Tap here to configure your API key",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFF59E0B)
                        )
                    }
                }
            }
            is FootballSyncStatus.LiveConnected -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF064E3B)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        text = if (isAr) "متصل بالنتائج المباشرة عبر ${status.providerName}"
                        else "Connected to Live Football API (${status.providerName})",
                        modifier = Modifier.padding(10.dp),
                        fontSize = 12.sp,
                        color = Color(0xFFA7F3D0)
                    )
                }
            }
            else -> {}
        }

        Spacer(modifier = Modifier.height(10.dp))

        val tabs = if (isAr) {
            listOf("المباريات والمواعيد", "جدول الترتيب", "أخبار الفريق")
        } else {
            listOf("Fixtures & Scores", "Standings", "Club News")
        }

        TabRow(selectedTabIndex = selectedTab) {
            tabs.forEachIndexed { idx, title ->
                Tab(
                    selected = selectedTab == idx,
                    onClick = { selectedTab = idx },
                    text = { Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (selectedTab == 0) {
                val matches = snapshot?.matches.orEmpty()
                items(matches) { m ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = m.competitionName,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = m.status,
                                    fontSize = 11.sp,
                                    color = if (m.isVerifiedLiveApi) Color(0xFF10B981) else Color(0xFFF59E0B)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isAr) m.homeTeamAr else m.homeTeamEn,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = if (m.homeScore != null && m.awayScore != null) {
                                        "${m.homeScore}  -  ${m.awayScore}"
                                    } else {
                                        "VS"
                                    },
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 18.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 12.dp)
                                )
                                Text(
                                    text = if (isAr) m.awayTeamAr else m.awayTeamEn,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "${m.utcDate} • ${m.venue}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            if (selectedTab == 1) {
                val rows = snapshot?.standings.orEmpty()
                items(rows) { row ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "#${row.position}  ${if (isAr) row.teamNameAr else row.teamNameEn}",
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "P:${row.played}  W:${row.won}  D:${row.drawn}  L:${row.lost}  PTS:${row.points}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            if (selectedTab == 2) {
                val newsList = snapshot?.news.orEmpty()
                items(newsList) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = if (isAr) item.titleAr else item.titleEn,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (isAr) item.summaryAr else item.summaryEn,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "${item.sourceName} • ${item.publishedLabel}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }

    if (showApiKeyDialog) {
        var apiKeyInput by remember { mutableStateOf(prefs.footballApiKey) }
        var providerInput by remember { mutableStateOf(prefs.footballApiProvider) }
        var notifEnabled by remember { mutableStateOf(prefs.matchNotificationsEnabled) }

        AlertDialog(
            onDismissRequest = { showApiKeyDialog = false },
            title = {
                Text(if (isAr) "إعداد مفتاح Football API" else "Configure Football Live API")
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = if (isAr) {
                            "أدخل مفتاح football-data.org (v4) أو API-Football لتفعيل النتائج المباشرة الحقيقية."
                        } else {
                            "Enter your football-data.org (v4) X-Auth-Token or API-Football key to fetch real live scores."
                        },
                        fontSize = 12.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = providerInput == "FOOTBALL_DATA_ORG",
                            onClick = { providerInput = "FOOTBALL_DATA_ORG" },
                            label = { Text("football-data.org") }
                        )
                        FilterChip(
                            selected = providerInput == "API_FOOTBALL",
                            onClick = { providerInput = "API_FOOTBALL" },
                            label = { Text("API-Football") }
                        )
                    }
                    OutlinedTextField(
                        value = apiKeyInput,
                        onValueChange = { apiKeyInput = it },
                        label = { Text("API Key / X-Auth-Token") },
                        singleLine = true
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (isAr) "تفعيل إشعارات المباريات" else "Enable Match Notifications")
                        Switch(checked = notifEnabled, onCheckedChange = { notifEnabled = it })
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onSaveApiConfig(apiKeyInput, providerInput, notifEnabled)
                    showApiKeyDialog = false
                }) {
                    Text(if (isAr) "حفظ وتحديث" else "Save & Sync")
                }
            },
            dismissButton = {
                TextButton(onClick = { showApiKeyDialog = false }) {
                    Text(if (isAr) "إلغاء" else "Cancel")
                }
            }
        )
    }
}
