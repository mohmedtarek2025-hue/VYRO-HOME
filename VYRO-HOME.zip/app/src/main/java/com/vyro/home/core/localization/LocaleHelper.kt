package com.vyro.home.core.localization

import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.os.LocaleListCompat
import java.util.Locale

object LocaleHelper {

    fun applyAppLanguage(languageTag: String) {
        val normalized = if (languageTag.startsWith("ar", ignoreCase = true)) "ar" else "en"
        val localeList = LocaleListCompat.forLanguageTags(normalized)
        AppCompatDelegate.setApplicationLocales(localeList)
    }

    fun getCurrentLanguageTag(): String {
        val current = AppCompatDelegate.getApplicationLocales()
        if (!current.isEmpty) {
            val tag = current[0]?.language ?: "en"
            return if (tag.startsWith("ar", ignoreCase = true)) "ar" else "en"
        }
        val sys = Locale.getDefault().language
        return if (sys.startsWith("ar", ignoreCase = true)) "ar" else "en"
    }

    fun getLayoutDirection(languageTag: String): LayoutDirection {
        return if (languageTag.startsWith("ar", ignoreCase = true)) {
            LayoutDirection.Rtl
        } else {
            LayoutDirection.Ltr
        }
    }
}
