package com.vyro.home

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vyro.home.core.localization.LocaleHelper
import com.vyro.home.ui.navigation.VyroNavHost
import com.vyro.home.ui.theme.VyroHomeTheme
import com.vyro.home.ui.viewmodel.VyroMainViewModel
import com.vyro.home.ui.viewmodel.VyroViewModelFactory

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val appContainer = (application as VyroHomeApplication).container
        val openQuickControlOnLaunch = intent?.getBooleanExtra("OPEN_QUICK_CONTROL_PANEL", false) == true

        setContent {
            val vm: VyroMainViewModel = viewModel(
                factory = VyroViewModelFactory(appContainer)
            )
            val uiState by vm.uiState.collectAsState()
            val layoutDirection = LocaleHelper.getLayoutDirection(uiState.preferences.languageTag)

            CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                VyroHomeTheme(
                    archetype = uiState.preferences.themeArchetype,
                    customAccentHex = uiState.preferences.customAccentHex,
                    useWallpaperDynamicColors = uiState.preferences.useWallpaperDynamicColors,
                    fontFamilyStyle = uiState.preferences.fontFamilyStyle
                ) {
                    VyroNavHost(
                        viewModel = vm,
                        uiState = uiState,
                        openQuickControlInitially = openQuickControlOnLaunch
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }
}
