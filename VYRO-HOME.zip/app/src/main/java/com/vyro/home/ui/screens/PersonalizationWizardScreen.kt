package com.vyro.home.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Preview
import androidx.compose.material.icons.filled.Sparkles
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyro.home.data.model.IconShapeStyle
import com.vyro.home.data.model.LayoutPresetType
import com.vyro.home.data.model.ThemeArchetype
import com.vyro.home.data.model.WallpaperPreset
import com.vyro.home.data.model.WidgetType
import com.vyro.home.ui.viewmodel.VyroUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PersonalizationWizardScreen(
    uiState: VyroUiState,
    onGeneratePreview: (
        ThemeArchetype, Long, Boolean, WallpaperPreset, IconShapeStyle,
        String, Float, LayoutPresetType, Int, Int, Float,
        List<WidgetType>, List<String>, List<String>, String
    ) -> Unit,
    onConfirmApply: (Boolean) -> Unit,
    onDiscardPreview: () -> Unit,
    onBack: () -> Unit
) {
    val isAr = uiState.isArabic
    val prefs = uiState.preferences

    var currentStep by remember { mutableIntStateOf(1) }
    val totalSteps = 4

    var selectedTheme by remember { mutableStateOf(prefs.themeArchetype) }
    var customAccentHex by remember { mutableLongStateOf(prefs.customAccentHex) }
    var useDynamicColors by remember { mutableStateOf(prefs.useWallpaperDynamicColors) }
    var selectedWallpaper by remember { mutableStateOf(prefs.wallpaperPreset) }
    var applyWallpaperToDevice by remember { mutableStateOf(false) }
    var selectedIconShape by remember { mutableStateOf(prefs.iconShapeStyle) }
    var selectedFont by remember { mutableStateOf(prefs.fontFamilyStyle) }
    var animSpeed by remember { mutableFloatStateOf(prefs.animationSpeedMultiplier) }

    var selectedPreset by remember {
        mutableStateOf(
            if (uiState.deviceReport.isSamsungDevice) LayoutPresetType.ONE_UI_ERGONOMIC
            else prefs.activeLayoutState.presetType
        )
    }
    var gridCols by remember { mutableIntStateOf(prefs.activeLayoutState.gridColumns) }
    var gridRows by remember { mutableIntStateOf(prefs.activeLayoutState.gridRows) }
    var iconScale by remember { mutableFloatStateOf(prefs.activeLayoutState.iconScale) }

    val selectedWidgets = remember {
        mutableStateListOf<WidgetType>().apply {
            addAll(prefs.activeLayoutState.activeWidgets)
        }
    }

    val selectedInterests = remember {
        mutableStateListOf<String>().apply {
            addAll(prefs.selectedInterests)
        }
    }

    val selectedTeams = remember {
        mutableStateListOf<String>().apply {
            addAll(prefs.selectedTeams)
        }
    }
    var primaryTeamId by remember { mutableStateOf(prefs.primaryTeamId) }

    val customColorSwatches = listOf(
        0xFF00E5FFL, 0xFF7C4DFFL, 0xFF10B981L, 0xFFFF007FL,
        0xFFD4AF37L, 0xFFFF2A54L, 0xFF38BDF8L, 0xFFF59E0BL
    )

    val allInterests = listOf(
        "FOOTBALL" to (if (isAr) "كرة القدم والرياضة" else "Football & Live Sports"),
        "GAMING" to (if (isAr) "الألعاب والأداء" else "Gaming & eSports"),
        "PRODUCTIVITY" to (if (isAr) "الإنتاجية والعمل" else "Productivity & Focus"),
        "SOCIAL" to (if (isAr) "التواصل الاجتماعي" else "Social & Messaging"),
        "MEDIA" to (if (isAr) "الوسائط والسينما" else "Media & Streaming"),
        "FINANCE" to (if (isAr) "المال والأعمال" else "Finance & Fintech")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
            .padding(18.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = {
                if (currentStep > 1) currentStep-- else onBack()
            }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (isAr) "معالج التخصيص الذكي" else "AUTOMATIC PERSONALIZATION WIZARD",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = if (isAr) "الخطوة $currentStep من $totalSteps" else "Step $currentStep of $totalSteps",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.size(40.dp))
        }

        Spacer(modifier = Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { currentStep.toFloat() / totalSteps.toFloat() },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(50))
        )

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (currentStep == 1) {
                item {
                    Text(
                        text = if (isAr) "1. اختر الثيم والألوان" else "1. Select Theme Archetype & Custom Colors",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isAr) {
                            "يدعم الوضع الداكن، النهاري، أموليد، الهادئ، النيون، البسيط، الفاخر، الألعاب، كرة القدم، والطبيعة."
                        } else {
                            "Choose from Dark, Light, AMOLED, Calm, Neon, Minimal, Luxury, Gaming, Football, or Nature themes."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeArchetype.entries.forEach { arch ->
                            val isSelected = selectedTheme == arch
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedTheme = arch
                                        customAccentHex = arch.primaryHex
                                    }
                                    .border(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) Color(arch.primaryHex) else Color(0x33FFFFFF),
                                        shape = RoundedCornerShape(14.dp)
                                    ),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = Color(arch.surfaceHex)
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(28.dp)
                                                .clip(CircleShape)
                                                .background(Color(arch.primaryHex))
                                        )
                                        Column {
                                            Text(
                                                text = if (isAr) arch.titleAr else arch.titleEn,
                                                color = if (arch.isDark) Color.White else Color.Black,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = if (arch.isAmoled) "True #000000 OLED" else arch.id.uppercase(),
                                                fontSize = 11.sp,
                                                color = Color(arch.secondaryHex)
                                            )
                                        }
                                    }
                                    if (isSelected) {
                                        Icon(
                                            Icons.Default.Check,
                                            contentDescription = null,
                                            tint = Color(arch.primaryHex)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = if (isAr) "لون التمييز المخصص (Custom Accent)" else "Custom Accent Color",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        customColorSwatches.forEach { hex ->
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(Color(hex))
                                    .border(
                                        width = if (customAccentHex == hex) 3.dp else 1.dp,
                                        color = if (customAccentHex == hex) Color.White else Color.Transparent,
                                        shape = CircleShape
                                    )
                                    .clickable { customAccentHex = hex },
                                contentAlignment = Alignment.Center
                            ) {
                                if (customAccentHex == hex) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black)
                                }
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isAr) "استخراج الألوان من الخلفية (Material You)" else "Dynamic Wallpaper Color Extraction",
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (isAr) "متاح على أندرويد 16 و 17" else "Extracts palette automatically on Android 16/17",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = useDynamicColors, onCheckedChange = { useDynamicColors = it })
                    }
                }
            }

            if (currentStep == 2) {
                item {
                    Text(
                        text = if (isAr) "2. الخلفيات وشكل الأيقونات" else "2. Wallpaper Preferences & Icon Styles",
                        style = MaterialTheme.typography.titleLarge
                    )
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        WallpaperPreset.entries.forEach { wp ->
                            val selected = selectedWallpaper == wp
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedWallpaper = wp },
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(wp.midColorHex))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (isAr) wp.nameAr else wp.nameEn,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (selected) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = Color(wp.accentGlowHex))
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (isAr) "تعيين كخلفية رئيسية للنظام أيضاً" else "Also apply wallpaper to Android system Home",
                            modifier = Modifier.weight(1f)
                        )
                        Checkbox(checked = applyWallpaperToDevice, onCheckedChange = { applyWallpaperToDevice = it })
                    }
                }

                item {
                    Text(
                        text = if (isAr) "نمط شكل الأيقونات" else "Icon Shape Style",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconShapeStyle.entries.forEach { style ->
                            FilterChip(
                                selected = selectedIconShape == style,
                                onClick = { selectedIconShape = style },
                                label = { Text(if (isAr) style.labelAr else style.labelEn) }
                            )
                        }
                    }
                }

                item {
                    Text(
                        text = if (isAr) "الخط وسرعة الحركة" else "Typography & Animation Speed (${String.format("%.1fx", animSpeed)})",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Slider(
                        value = animSpeed,
                        onValueChange = { animSpeed = it },
                        valueRange = 0.5f..1.5f
                    )
                }
            }

            if (currentStep == 3) {
                item {
                    Text(
                        text = if (isAr) "3. تفضيلات التخطيط والودجات" else "3. Layout Presets, Grid & Widgets",
                        style = MaterialTheme.typography.titleLarge
                    )
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        LayoutPresetType.entries.forEach { preset ->
                            val isSelected = selectedPreset == preset
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedPreset = preset
                                        gridCols = preset.columns
                                        gridRows = preset.rows
                                    }
                                    .border(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                        shape = RoundedCornerShape(14.dp)
                                    ),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = if (isAr) preset.nameAr else preset.nameEn,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (isAr) preset.descAr else preset.descEn,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = if (isAr) "حجم الشبكة: $gridCols أعمدة × $gridRows صفوف" else "Grid Configuration: ${gridCols}x${gridRows}",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(4 to 5, 4 to 6, 5 to 5, 5 to 6).forEach { (c, r) ->
                            FilterChip(
                                selected = gridCols == c && gridRows == r,
                                onClick = {
                                    gridCols = c
                                    gridRows = r
                                },
                                label = { Text("${c}x${r}") }
                            )
                        }
                    }
                }

                item {
                    Text(
                        text = if (isAr) "حجم الأيقونات (${(iconScale * 100).toInt()}%)" else "Icon Scale (${(iconScale * 100).toInt()}%)",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Slider(
                        value = iconScale,
                        onValueChange = { iconScale = it },
                        valueRange = 0.85f..1.25f
                    )
                }

                item {
                    Text(
                        text = if (isAr) "الودجات النشطة" else "Active Workspace Widgets",
                        style = MaterialTheme.typography.titleMedium
                    )
                    WidgetType.entries.forEach { w ->
                        val checked = selectedWidgets.contains(w)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (checked) selectedWidgets.remove(w) else selectedWidgets.add(w)
                                }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(if (isAr) w.titleAr else w.titleEn)
                            Checkbox(
                                checked = checked,
                                onCheckedChange = {
                                    if (it) {
                                        if (!selectedWidgets.contains(w)) selectedWidgets.add(w)
                                    } else {
                                        selectedWidgets.remove(w)
                                    }
                                }
                            )
                        }
                    }
                }
            }

            if (currentStep == 4) {
                item {
                    Text(
                        text = if (isAr) "4. الاهتمامات والفرق المفضلة" else "4. Interests & Favorite Football Teams",
                        style = MaterialTheme.typography.titleLarge
                    )
                }

                item {
                    Text(
                        text = if (isAr) "اختر اهتماماتك لترتيب التطبيقات تلقائياً:" else "Select interests for automatic app prioritization:",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        allInterests.forEach { (id, label) ->
                            val isSel = selectedInterests.contains(id)
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    if (isSel) selectedInterests.remove(id) else selectedInterests.add(id)
                                },
                                label = { Text(label) }
                            )
                        }
                    }
                }

                item {
                    Text(
                        text = if (isAr) "الفرق والمنتخبات المفضلة (مركز كرة القدم):" else "Favorite Football Teams (Football Hub):",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        uiState.supportedTeams.forEach { team ->
                            val isSelected = selectedTeams.contains(team.id)
                            val isPrimary = primaryTeamId == team.id
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (!isSelected) selectedTeams.add(team.id)
                                        primaryTeamId = team.id
                                    }
                                    .border(
                                        width = if (isPrimary) 2.dp else 1.dp,
                                        color = if (isPrimary) Color(team.primaryColorHex) else Color.Transparent,
                                        shape = RoundedCornerShape(14.dp)
                                    ),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .clip(CircleShape)
                                                .background(Color(team.primaryColorHex))
                                        )
                                        Column {
                                            Text(
                                                text = if (isAr) team.nameAr else team.nameEn,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = if (isAr) team.leagueAr else team.leagueEn,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    if (isPrimary) {
                                        Text(
                                            text = if (isAr) "الفريق الرئيسي ★" else "PRIMARY ★",
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom Navigation Buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (currentStep > 1) {
                OutlinedButton(
                    onClick = { currentStep-- },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                ) {
                    Text(if (isAr) "السابق" else "Previous")
                }
            }

            Button(
                onClick = {
                    if (currentStep < totalSteps) {
                        currentStep++
                    } else {
                        onGeneratePreview(
                            selectedTheme,
                            customAccentHex,
                            useDynamicColors,
                            selectedWallpaper,
                            selectedIconShape,
                            selectedFont,
                            animSpeed,
                            selectedPreset,
                            gridCols,
                            gridRows,
                            iconScale,
                            selectedWidgets.toList(),
                            selectedInterests.toList(),
                            selectedTeams.toList(),
                            primaryTeamId
                        )
                    }
                },
                modifier = Modifier
                    .weight(1.4f)
                    .height(52.dp)
            ) {
                Icon(
                    if (currentStep < totalSteps) Icons.Default.Sparkles else Icons.Default.Preview,
                    contentDescription = null
                )
                Spacer(modifier = Modifier.size(8.dp))
                Text(
                    text = if (currentStep < totalSteps) {
                        if (isAr) "التالي" else "Continue"
                    } else {
                        if (isAr) "معاينة وتوليد التخطيط" else "Preview Auto-Layout"
                    },
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    // Live Preview Before Applying Modal
    val previewCandidate = uiState.previewLayoutCandidate
    if (previewCandidate != null) {
        AlertDialog(
            onDismissRequest = onDiscardPreview,
            title = {
                Text(
                    text = if (isAr) "معاينة التخطيط الذكي قبل التطبيق" else "Preview Generated VYRO Layout",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isAr) {
                            "قام محرك VYRO بتنظيم تطبيقاتك تلقائياً دون تعديل أو حذف أي تطبيق:"
                        } else {
                            "VYRO Auto-Layout Engine organized your installed apps non-destructively:"
                        }
                    )
                    Text("• ${if (isAr) "النمط" else "Preset"}: ${if (isAr) previewCandidate.presetType.nameAr else previewCandidate.presetType.nameEn}")
                    Text("• ${if (isAr) "الشبكة" else "Grid"}: ${previewCandidate.gridColumns}x${previewCandidate.gridRows} (${(previewCandidate.iconScale * 100).toInt()}%)")
                    Text("• ${if (isAr) "المجلدات الذكية" else "Smart Folders Created"}: ${previewCandidate.smartFolders.size}")
                    previewCandidate.smartFolders.take(4).forEach { folder ->
                        Text(
                            text = "   - ${if (isAr) folder.titleAr else folder.titleEn} (${folder.appPackages.size} apps)",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Text("• ${if (isAr) "تطبيقات الشريط السفلي" else "Dock Favorites"}: ${previewCandidate.dockPackages.size}")
                }
            },
            confirmButton = {
                Button(onClick = { onConfirmApply(applyWallpaperToDevice) }) {
                    Text(if (isAr) "تطبيق التخطيط الآن" else "Apply VYRO Layout")
                }
            },
            dismissButton = {
                TextButton(onClick = onDiscardPreview) {
                    Text(if (isAr) "تعديل الخيارات" else "Adjust Selections")
                }
            }
        )
    }
}
