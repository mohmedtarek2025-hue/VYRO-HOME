package com.vyro.home.data.backup

import android.content.Context
import android.net.Uri
import com.vyro.home.data.local.LayoutSnapshotEntity
import com.vyro.home.data.local.VyroDao
import com.vyro.home.data.model.LauncherLayoutState
import com.vyro.home.data.model.VyroBackupPayload
import com.vyro.home.data.preferences.UserPreferencesState
import com.vyro.home.data.preferences.VyroPreferencesRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Manages full configuration export/import (external JSON backup files via Storage Access Framework)
 * and Room layout snapshot history (Undo / Restore Previous Layout).
 *
 * IMPORTANT DISCLOSURE:
 * Uninstalling VYRO HOME removes its internal app sandbox database and DataStore preferences unless
 * the user exports an external JSON backup file via Storage Access Framework or has Android Auto Backup
 * enabled on their Google/Samsung cloud account. VYRO HOME never modifies or damages the device's
 * original stock launcher configuration.
 */
class BackupRestoreManager(
    private val context: Context,
    private val prefsRepo: VyroPreferencesRepository,
    private val dao: VyroDao
) {
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun buildBackupPayload(state: UserPreferencesState): VyroBackupPayload {
        return VyroBackupPayload(
            languageTag = state.languageTag,
            themeArchetype = state.themeArchetype,
            customAccentHex = state.customAccentHex,
            useWallpaperDynamicColors = state.useWallpaperDynamicColors,
            wallpaperPreset = state.wallpaperPreset,
            iconShapeStyle = state.iconShapeStyle,
            fontFamilyStyle = state.fontFamilyStyle,
            animationSpeedMultiplier = state.animationSpeedMultiplier,
            selectedTeams = state.selectedTeams,
            primaryTeamId = state.primaryTeamId,
            selectedInterests = state.selectedInterests,
            layoutState = state.activeLayoutState,
            lockScreenConfig = state.lockScreenConfig
        )
    }

    fun serializePayloadToJson(state: UserPreferencesState): String {
        return json.encodeToString(buildBackupPayload(state))
    }

    suspend fun exportBackupToUri(uri: Uri, state: UserPreferencesState): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val payloadJson = serializePayloadToJson(state)
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(payloadJson.toByteArray(Charsets.UTF_8))
                    out.flush()
                } ?: error("Unable to open output stream for URI: $uri")
            }
        }

    suspend fun importBackupFromUri(uri: Uri): Result<VyroBackupPayload> =
        withContext(Dispatchers.IO) {
            runCatching {
                val content = context.contentResolver.openInputStream(uri)?.use { input ->
                    BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                } ?: error("Unable to read backup file from URI: $uri")

                val payload = json.decodeFromString<VyroBackupPayload>(content)
                prefsRepo.importBackupPayload(payload)
                recordLayoutSnapshot(payload.layoutState, "Imported External Backup")
                payload
            }
        }

    suspend fun recordLayoutSnapshot(layout: LauncherLayoutState, label: String) {
        val entity = LayoutSnapshotEntity(
            createdAtEpochMs = System.currentTimeMillis(),
            label = label,
            presetId = layout.presetType.id,
            layoutJson = json.encodeToString(layout)
        )
        dao.insertLayoutSnapshot(entity)
    }

    fun decodeSnapshot(entity: LayoutSnapshotEntity): LauncherLayoutState? {
        return runCatching {
            json.decodeFromString<LauncherLayoutState>(entity.layoutJson)
        }.getOrNull()
    }
}
