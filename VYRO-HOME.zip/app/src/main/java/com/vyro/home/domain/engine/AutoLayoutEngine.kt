package com.vyro.home.domain.engine

import com.vyro.home.data.model.AppCategory
import com.vyro.home.data.model.InstalledAppInfo
import com.vyro.home.data.model.LauncherLayoutState
import com.vyro.home.data.model.LayoutPresetType
import com.vyro.home.data.model.SmartFolderModel
import com.vyro.home.data.model.ThemeArchetype
import com.vyro.home.data.model.WidgetType

/**
 * Automatic Personalization & Launcher Layout Generation Engine.
 * Organizes installed apps into categorized Smart Folders, selects dock and home screen
 * favorites prioritized by user interests, places widgets, and supports non-destructive preview/undo.
 */
class AutoLayoutEngine {

    fun generateOptimizedLayout(
        installedApps: List<InstalledAppInfo>,
        preset: LayoutPresetType,
        theme: ThemeArchetype,
        selectedWidgets: List<WidgetType>,
        selectedInterests: List<String>,
        isSamsungDevice: Boolean,
        customColumns: Int? = null,
        customRows: Int? = null,
        customIconScale: Float = 1.0f
    ): LauncherLayoutState {
        val cols = customColumns ?: preset.columns
        val rows = customRows ?: preset.rows
        val dockLimit = preset.dockCount

        // 1. Select Dock Apps (Phone, Messages, Browser, Camera, Settings/App)
        val dockApps = pickDockPackages(installedApps, dockLimit)

        // 2. Group apps by category into Smart Folders
        val grouped = installedApps.groupBy { it.category }
        val priorityCategories = buildPriorityCategoryOrder(selectedInterests)

        val smartFolders = priorityCategories.mapNotNull { category ->
            val appsInCat = grouped[category].orEmpty()
            if (appsInCat.isEmpty()) return@mapNotNull null
            SmartFolderModel(
                id = "folder_${category.id}",
                titleEn = category.titleEn,
                titleAr = category.titleAr,
                category = category,
                appPackages = appsInCat.map { it.packageName },
                accentHex = resolveFolderAccent(category, theme)
            )
        }

        // 3. Pick top Favorite Apps for direct workspace placement based on user interests
        val favoriteLimit = (cols * 2).coerceIn(6, 10)
        val preferredPackages = installedApps
            .sortedWith(
                compareBy<InstalledAppInfo> { app ->
                    val idx = priorityCategories.indexOf(app.category)
                    if (idx == -1) 99 else idx
                }.thenBy { it.label.lowercase() }
            )
            .map { it.packageName }
            .filterNot { dockApps.contains(it) }
            .take(favoriteLimit)

        val finalFavorites = if (preferredPackages.isNotEmpty()) {
            preferredPackages
        } else {
            installedApps.map { it.packageName }.take(favoriteLimit)
        }

        val reachMode = preset.oneUiReachHeader || (isSamsungDevice && preset == LayoutPresetType.ONE_UI_ERGONOMIC)

        return LauncherLayoutState(
            timestamp = System.currentTimeMillis(),
            description = "${preset.nameEn} • ${theme.titleEn}",
            presetType = preset,
            gridColumns = cols,
            gridRows = rows,
            dockCount = dockLimit,
            iconScale = customIconScale.coerceIn(0.85f, 1.25f),
            oneUiReachEnabled = reachMode,
            activeWidgets = selectedWidgets.ifEmpty {
                listOf(WidgetType.CLOCK_WEATHER, WidgetType.FOOTBALL_LIVE)
            },
            smartFolders = smartFolders,
            favoritePackages = finalFavorites,
            dockPackages = dockApps
        )
    }

    private fun pickDockPackages(apps: List<InstalledAppInfo>, limit: Int): List<String> {
        val result = mutableListOf<String>()
        val matchers: List<(InstalledAppInfo) -> Boolean> = listOf(
            { it.packageName.contains("dialer") || it.packageName.contains("phone") || it.label.equals("Phone", true) },
            { it.packageName.contains("messaging") || it.packageName.contains("mms") || it.packageName.contains("whatsapp") },
            { it.packageName.contains("chrome") || it.packageName.contains("browser") || it.packageName.contains("sbrowser") },
            { it.packageName.contains("camera") },
            { it.packageName.contains("settings") || it.category == AppCategory.FOOTBALL_SPORTS }
        )
        for (matcher in matchers) {
            if (result.size >= limit) break
            val found = apps.firstOrNull { matcher(it) && !result.contains(it.packageName) }
            if (found != null) result.add(found.packageName)
        }
        for (app in apps) {
            if (result.size >= limit) break
            if (!result.contains(app.packageName)) {
                result.add(app.packageName)
            }
        }
        return result
    }

    private fun buildPriorityCategoryOrder(interests: List<String>): List<AppCategory> {
        val ordered = mutableListOf<AppCategory>()
        val upper = interests.map { it.uppercase() }
        if (upper.any { it.contains("FOOTBALL") || it.contains("SPORT") }) ordered.add(AppCategory.FOOTBALL_SPORTS)
        if (upper.any { it.contains("GAME") || it.contains("GAMING") }) ordered.add(AppCategory.GAMES)
        if (upper.any { it.contains("PRODUCTIVITY") || it.contains("WORK") }) ordered.add(AppCategory.PRODUCTIVITY)
        if (upper.any { it.contains("SOCIAL") }) ordered.add(AppCategory.SOCIAL)
        if (upper.any { it.contains("MEDIA") }) ordered.add(AppCategory.MEDIA)
        if (upper.any { it.contains("FINANCE") }) ordered.add(AppCategory.FINANCE)

        for (cat in AppCategory.entries) {
            if (!ordered.contains(cat)) ordered.add(cat)
        }
        return ordered
    }

    private fun resolveFolderAccent(category: AppCategory, theme: ThemeArchetype): Long {
        return when (category) {
            AppCategory.FOOTBALL_SPORTS -> 0xFF10B981
            AppCategory.GAMES -> 0xFFFF2A54
            AppCategory.SOCIAL -> 0xFF38BDF8
            AppCategory.PRODUCTIVITY -> 0xFFF59E0B
            AppCategory.MEDIA -> 0xFFA855F7
            AppCategory.FINANCE -> 0xFF34D399
            AppCategory.UTILITIES -> theme.primaryHex
            AppCategory.OTHER -> theme.secondaryHex
        }
    }
}
