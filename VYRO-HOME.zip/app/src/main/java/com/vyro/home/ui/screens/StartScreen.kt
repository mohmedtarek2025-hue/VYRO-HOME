package com.vyro.home.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyro.home.ui.viewmodel.VyroUiState

@Composable
fun StartScreen(
    uiState: VyroUiState,
    onToggleLanguage: (String) -> Unit,
    onStartClicked: () -> Unit,
    onSkipToHome: () -> Unit
) {
    val isAr = uiState.isArabic
    val infiniteTransition = rememberInfiniteTransition(label = "vyro_start_orbit")

    val orbitAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(16000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orbit_angle"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val bgBrush = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF050814),
            Color(0xFF0D1836),
            Color(0xFF070C1B),
            Color(0xFF03050C)
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgBrush)
            .systemBarsPadding()
    ) {
        // Futuristic Orbital Mesh Background Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width * 0.5f
            val cy = size.height * 0.36f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x4400E5FF), Color(0x117C4DFF), Color.Transparent),
                    center = Offset(cx, cy),
                    radius = size.minDimension * 0.65f
                ),
                center = Offset(cx, cy),
                radius = size.minDimension * 0.65f
            )
            rotate(orbitAngle, pivot = Offset(cx, cy)) {
                drawCircle(
                    color = Color(0x3300E5FF),
                    radius = size.minDimension * 0.34f,
                    center = Offset(cx, cy),
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar: Language Toggle (English / العربية) & Device Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = Color(0x2200E5FF),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.border(1.dp, Color(0x5500E5FF), RoundedCornerShape(50))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhoneAndroid,
                            contentDescription = null,
                            tint = Color(0xFF00E5FF),
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "${uiState.deviceReport.manufacturer.uppercase()} • API ${uiState.deviceReport.sdkInt}",
                            color = Color(0xFFE2E8F0),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !isAr,
                        onClick = { onToggleLanguage("en") },
                        label = { Text("EN", fontWeight = FontWeight.Bold) },
                        leadingIcon = {
                            Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(15.dp))
                        }
                    )
                    FilterChip(
                        selected = isAr,
                        onClick = { onToggleLanguage("ar") },
                        label = { Text("العربية", fontWeight = FontWeight.Bold) }
                    )
                }
            }

            // Center: Animated VYRO HOME Emblem & Typography
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 12.dp)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(156.dp)
                        .scale(pulseScale)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(Color(0x3300E5FF), Color(0x117C4DFF), Color.Transparent)
                            )
                        )
                        .border(
                            width = 2.dp,
                            brush = Brush.linearGradient(listOf(Color(0xFF00E5FF), Color(0xFF7C4DFF))),
                            shape = CircleShape
                        )
                ) {
                    Canvas(modifier = Modifier.size(92.dp)) {
                        val w = size.width
                        val h = size.height
                        val path = Path().apply {
                            moveTo(w * 0.15f, h * 0.2f)
                            lineTo(w * 0.5f, h * 0.85f)
                            lineTo(w * 0.85f, h * 0.2f)
                            lineTo(w * 0.68f, h * 0.2f)
                            lineTo(w * 0.5f, h * 0.56f)
                            lineTo(w * 0.32f, h * 0.2f)
                            close()
                        }
                        drawPath(
                            path = path,
                            brush = Brush.linearGradient(
                                listOf(Color(0xFF00E5FF), Color(0xFF7C4DFF))
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "VYRO HOME",
                    fontSize = 36.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 4.sp,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (isAr) {
                        "لانشر أندرويد المستقبلي الذكي • تخصيص تلقائي متكامل"
                    } else {
                        "FUTURISTIC AUTONOMOUS ANDROID 16 & 17 LAUNCHER"
                    },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF38BDF8),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = if (isAr) {
                        uiState.deviceReport.oneUi9DisclosureAr
                    } else {
                        uiState.deviceReport.oneUi9DisclosureEn
                    },
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8),
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0x19FFFFFF), RoundedCornerShape(14.dp))
                        .padding(12.dp)
                )
            }

            // Bottom Actions: Prominent START Button + Direct Workspace Jump
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onStartClicked,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00E5FF),
                        contentColor = Color(0xFF040914)
                    )
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null)
                    Spacer(modifier = Modifier.size(10.dp))
                    Text(
                        text = if (isAr) "ابدأ التخصيص الذكي (START)" else "START PERSONALIZATION",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }

                OutlinedButton(
                    onClick = onSkipToHome,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = if (isAr) "الدخول مباشرة إلى الشاشة الرئيسية" else "Enter Default VYRO Workspace Directly",
                        color = Color(0xFFCBD5E1)
                    )
                }
            }
        }
    }
}
