package com.vyro.home.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.vyro.home.VyroAppContainer
import com.vyro.home.core.device.DeviceCapabilityReport
import com.vyro.home.core.localization.LocaleHelper
import com.vyro.home.core.system.SystemTelemetryState
import com.vyro.home.data.local.LayoutSnapshotEntity
import com.vyro.home.data.model.AppCategory
import com.vyro.home.data.model.FootballTeamProfile
import com.vyro.home.data.model.IconShapeStyle
import com.vyro.home.data.model.InstalledAppInfo
import com.vyro.home.data.model.LauncherLayoutState
import com.vyro.home.data.model.LayoutPresetType
import com.vyro.home.data.model.LockScreenConfig
import com.vyro.home.data.model.SmartFolderModel
import com.vyro.home.data.model.ThemeArchetype
import com.vyro.home.data.model.WallpaperPreset
import com.vyro.home.data.model.WidgetType
import com.vyro.home.data.preferences.UserPreferencesState
import com.vyro.home.domain.football.FootballSyncStatus
import com.vyro.home.domain.football.TeamHubSnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class VyroUiState(
    val preferences: UserPreferencesState = UserPreferencesState(),
    val deviceReport: DeviceCapabilityReport,
    val installedApps: List<InstalledAppInfo> = emptyList(),
    val layoutSnapshots: List<LayoutSnapshotEntity> = emptyList(),
    val previewLayoutCandidate: LauncherLayoutState? = null,
    val systemTelemetry: SystemTelemetryState = SystemTelemetryState(),
    val footballSnapshot: TeamHubSnapshot? = null,
    val supportedTeams: List<FootballTeamProfile> = emptyList(),
    val statusBannerMessage: String? = null
) {
    val isArabic: Boolean get() = preferences.languageTag.startsWith("ar", ignoreCase = true)
}

class VyroMainViewModel(
    private val container: VyroAppContainer
) : ViewModel() {

    private val deviceReport = container.deviceCapabilityManager.inspectDevice()
    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    private val _previewCandidate = MutableStateFlow<LauncherLayoutState?>(null)
    private val _footballSnapshot = MutableStateFlow<TeamHubSnapshot?>(null)
    private val _statusMessage = MutableStateFlow<String?>(null)

    val uiState: StateFlow<VyroUiState> = combine(
        container.preferencesRepository.preferencesFlow,
        _installedApps,
        container.database.vyroDao().observeLayoutSnapshots(),
        _previewCandidate,
        container.systemControlController.telemetry
    ) { prefs, apps, snapshots, preview, telemetry ->
        VyroUiState(
            preferences = prefs,
            deviceReport = deviceReport,
            installedApps = apps,
            layoutSnapshots = snapshots,
            previewLayoutCandidate = preview,
            systemTelemetry = telemetry,
            footballSnapshot = _footballSnapshot.value,
            supportedTeams = container.footballRepository.supportedTeams,
            statusBannerMessage = _statusMessage.value
        )
    }.combine(_footballSnapshot) { base, football ->
        base.copy(footballSnapshot = football)
    }.combine(_statusMessage) { base, msg ->
        base.copy(statusBannerMessage = msg)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = VyroUiState(
            deviceReport = deviceReport,
            supportedTeams = container.footballRepository.supportedTeams
        )
    )

    init {
        refreshInstalledAppsAndInitialLayout()
    }

    fun clearStatusBanner() {
        _statusMessage.value = null
    }

    fun refreshInstalledAppsAndInitialLayout() {
        viewModelScope.launch {
            val apps = container.launcherAppRepository.loadInstalledApps()
            _installedApps.value = apps
            container.systemControlController.refreshTelemetry()

            val currentPrefs = uiState.value.preferences
            if (currentPrefs.activeLayoutState.smartFolders.isEmpty() && apps.isNotEmpty()) {
                val initialPreset = if (deviceReport.isSamsungDevice) {
                    LayoutPresetType.ONE_UI_ERGONOMIC
                } else {
                    LayoutPresetType.MINIMAL_ZEN
                }
                val generated = container.autoLayoutEngine.generateOptimizedLayout(
                    installedApps = apps,
                    preset = initialPreset,
                    theme = currentPrefs.themeArchetype,
                    selectedWidgets = listOf(WidgetType.CLOCK_WEATHER, WidgetType.FOOTBALL_LIVE),
                    selectedInterests = currentPrefs.selectedInterests,
                    isSamsungDevice = deviceReport.isSamsungDevice
                )
                container.preferencesRepository.saveAppliedLayout(generated, markOnboardingComplete = false)
                container.backupRestoreManager.recordLayoutSnapshot(generated, "Initial Auto-Generated Layout")
            }
            refreshFootballHub(currentPrefs.primaryTeamId)
        }
    }

    fun switchLanguage(languageTag: String) {
        viewModelScope.launch {
            container.preferencesRepository.setLanguageTag(languageTag)
            LocaleHelper.applyAppLanguage(languageTag)
        }
    }

    fun generateWizardPreview(
        theme: ThemeArchetype,
        customAccentHex: Long,
        useDynamicColors: Boolean,
        wallpaper: WallpaperPreset,
        iconShape: IconShapeStyle,
        fontStyle: String,
        animSpeed: Float,
        preset: LayoutPresetType,
        columns: Int,
        rows: Int,
        iconScale: Float,
        widgets: List<WidgetType>,
        interests: List<String>,
        teams: List<String>,
        primaryTeamId: String
    ) {
        viewModelScope.launch {
            container.preferencesRepository.updateTheme(theme, customAccentHex, useDynamicColors)
            container.preferencesRepository.updateWallpaperAndIcons(wallpaper, iconShape, fontStyle, animSpeed)
            container.preferencesRepository.updateInterestsAndTeams(interests, teams, primaryTeamId)

            val apps = _installedApps.value.ifEmpty { container.launcherAppRepository.loadInstalledApps() }
            val candidate = container.autoLayoutEngine.generateOptimizedLayout(
                installedApps = apps,
                preset = preset,
                theme = theme,
                selectedWidgets = widgets,
                selectedInterests = interests,
                isSamsungDevice = deviceReport.isSamsungDevice,
                customColumns = columns,
                customRows = rows,
                customIconScale = iconScale
            )
            _previewCandidate.value = candidate
            refreshFootballHub(primaryTeamId)
        }
    }

    fun confirmAndApplyPreviewLayout(applyWallpaperToSystem: Boolean = false) {
        viewModelScope.launch {
            val candidate = _previewCandidate.value ?: uiState.value.preferences.activeLayoutState
            container.backupRestoreManager.recordLayoutSnapshot(
                candidate,
                "Applied ${candidate.presetType.nameEn}"
            )
            container.preferencesRepository.saveAppliedLayout(candidate, markOnboardingComplete = true)
            if (applyWallpaperToSystem) {
                container.systemControlController.applyPresetWallpaperToSystem(
                    preset = uiState.value.preferences.wallpaperPreset,
                    applyToHome = true,
                    applyToLock = false
                )
            }
            _previewCandidate.value = null
            _statusMessage.value = if (uiState.value.isArabic) {
                "تم توليد وتطبيق تخطيط VYRO HOME بنجاح!"
            } else {
                "VYRO HOME personalized layout applied and saved to undo history."
            }
        }
    }

    fun discardPreviewCandidate() {
        _previewCandidate.value = null
    }

    fun applyQuickPreset(preset: LayoutPresetType) {
        viewModelScope.launch {
            val prefs = uiState.value.preferences
            val generated = container.autoLayoutEngine.generateOptimizedLayout(
                installedApps = _installedApps.value,
                preset = preset,
                theme = prefs.themeArchetype,
                selectedWidgets = prefs.activeLayoutState.activeWidgets,
                selectedInterests = prefs.selectedInterests,
                isSamsungDevice = deviceReport.isSamsungDevice,
                customIconScale = prefs.activeLayoutState.iconScale
            )
            container.backupRestoreManager.recordLayoutSnapshot(generated, "Preset: ${preset.nameEn}")
            container.preferencesRepository.saveAppliedLayout(generated, markOnboardingComplete = true)
            _statusMessage.value = if (uiState.value.isArabic) {
                "تم تطبيق نمط التخطيط: ${preset.nameAr}"
            } else {
                "Applied layout preset: ${preset.nameEn}"
            }
        }
    }

    fun undoLastLayoutChange() {
        viewModelScope.launch {
            val latestTwo = container.database.vyroDao().getLatestTwoSnapshots()
            if (latestTwo.size >= 2) {
                val current = latestTwo[0]
                val previous = latestTwo[1]
                val decoded = container.backupRestoreManager.decodeSnapshot(previous)
                if (decoded != null) {
                    container.database.vyroDao().deleteSnapshotById(current.id)
                    container.preferencesRepository.saveAppliedLayout(decoded, markOnboardingComplete = true)
                    _statusMessage.value = if (uiState.value.isArabic) {
                        "تم التراجع واستعادة التخطيط السابق: ${previous.label}"
                    } else {
                        "Reverted to previous layout: ${previous.label}"
                    }
                }
            } else {
                _statusMessage.value = if (uiState.value.isArabic) {
                    "لا يوجد تخطيط أقدم للتراجع إليه."
                } else {
                    "No earlier layout snapshot in history to undo."
                }
            }
        }
    }

    fun restoreSnapshot(entity: LayoutSnapshotEntity) {
        viewModelScope.launch {
            val decoded = container.backupRestoreManager.decodeSnapshot(entity) ?: return@launch
            container.preferencesRepository.saveAppliedLayout(decoded, markOnboardingComplete = true)
            _statusMessage.value = if (uiState.value.isArabic) {
                "تم استعادة النسخة: ${entity.label}"
            } else {
                "Restored snapshot: ${entity.label}"
            }
        }
    }

    fun createCustomSmartFolder(titleEn: String, titleAr: String, selectedPackages: List<String>) {
        if (selectedPackages.isEmpty()) return
        viewModelScope.launch {
            val currentLayout = uiState.value.preferences.activeLayoutState
            val newFolder = SmartFolderModel(
                id = "custom_${System.currentTimeMillis()}",
                titleEn = titleEn.ifBlank { "Custom Folder" },
                titleAr = titleAr.ifBlank { "مجلد مخصص" },
                category = AppCategory.OTHER,
                appPackages = selectedPackages,
                accentHex = uiState.value.preferences.customAccentHex
            )
            val updated = currentLayout.copy(
                timestamp = System.currentTimeMillis(),
                smartFolders = listOf(newFolder) + currentLayout.smartFolders
            )
            container.backupRestoreManager.recordLayoutSnapshot(updated, "Created Folder: $titleEn")
            container.preferencesRepository.saveAppliedLayout(updated, markOnboardingComplete = true)
        }
    }

    fun toggleOneUiReachMode(enabled: Boolean) {
        viewModelScope.launch {
            val current = uiState.value.preferences.activeLayoutState
            val updated = current.copy(oneUiReachEnabled = enabled)
            container.preferencesRepository.saveAppliedLayout(updated, markOnboardingComplete = true)
        }
    }

    fun updateGridAndScale(columns: Int, rows: Int, iconScale: Float) {
        viewModelScope.launch {
            val current = uiState.value.preferences.activeLayoutState
            val updated = current.copy(
                gridColumns = columns.coerceIn(3, 6),
                gridRows = rows.coerceIn(4, 7),
                iconScale = iconScale.coerceIn(0.85f, 1.25f)
            )
            container.backupRestoreManager.recordLayoutSnapshot(updated, "Grid ${columns}x${rows}")
            container.preferencesRepository.saveAppliedLayout(updated, markOnboardingComplete = true)
        }
    }

    fun launchInstalledApp(app: InstalledAppInfo) {
        container.launcherAppRepository.launchApp(app)
    }

    fun openAppDetails(packageName: String) {
        container.launcherAppRepository.openAppSystemInfo(packageName)
    }

    // Theme & Wallpaper Quick Controls
    fun selectTheme(archetype: ThemeArchetype, customAccentHex: Long = archetype.primaryHex, useDynamic: Boolean = false) {
        viewModelScope.launch {
            val extracted = if (useDynamic) {
                container.systemControlController.extractWallpaperPrimaryColorHex() ?: customAccentHex
            } else {
                customAccentHex
            }
            container.preferencesRepository.updateTheme(archetype, extracted, useDynamic)
        }
    }

    fun selectWallpaperAndApply(preset: WallpaperPreset, applySystemHome: Boolean, applySystemLock: Boolean) {
        viewModelScope.launch {
            val prefs = uiState.value.preferences
            container.preferencesRepository.updateWallpaperAndIcons(
                wallpaper = preset,
                iconShape = prefs.iconShapeStyle,
                fontStyle = prefs.fontFamilyStyle,
                animSpeed = prefs.animationSpeedMultiplier
            )
            if (applySystemHome || applySystemLock) {
                val ok = container.systemControlController.applyPresetWallpaperToSystem(
                    preset = preset,
                    applyToHome = applySystemHome,
                    applyToLock = applySystemLock
                )
                _statusMessage.value = if (ok) {
                    if (uiState.value.isArabic) "تم تطبيق خلفية ${preset.nameAr} على النظام"
                    else "Applied ${preset.nameEn} wallpaper to system"
                } else {
                    if (uiState.value.isArabic) "تم تحديث خلفية اللانشر الداخلية"
                    else "Updated VYRO HOME internal wallpaper"
                }
            }
        }
    }

    fun selectIconShape(shape: IconShapeStyle) {
        viewModelScope.launch {
            val prefs = uiState.value.preferences
            container.preferencesRepository.updateWallpaperAndIcons(
                wallpaper = prefs.wallpaperPreset,
                iconShape = shape,
                fontStyle = prefs.fontFamilyStyle,
                animSpeed = prefs.animationSpeedMultiplier
            )
        }
    }

    // Football Hub Actions
    fun refreshFootballHub(teamId: String = uiState.value.preferences.primaryTeamId) {
        viewModelScope.launch {
            val prefs = uiState.value.preferences
            val currentTeam = container.footballRepository.getTeamById(teamId)
            _footballSnapshot.value = TeamHubSnapshot(
                team = currentTeam,
                syncStatus = FootballSyncStatus.Loading,
                matches = emptyList(),
                standings = emptyList(),
                news = emptyList()
            )
            val snapshot = container.footballRepository.loadTeamHubSnapshot(
                teamId = teamId,
                apiKey = prefs.footballApiKey,
                provider = prefs.footballApiProvider
            )
            _footballSnapshot.value = snapshot
        }
    }

    fun selectPrimaryFootballTeam(teamId: String, applyTeamThemeColors: Boolean = false) {
        viewModelScope.launch {
            val prefs = uiState.value.preferences
            val updatedTeams = (listOf(teamId) + prefs.selectedTeams).distinct()
            container.preferencesRepository.updateInterestsAndTeams(
                interests = prefs.selectedInterests,
                teams = updatedTeams,
                primaryTeamId = teamId
            )
            if (applyTeamThemeColors) {
                val team = container.footballRepository.getTeamById(teamId)
                container.preferencesRepository.updateTheme(
                    archetype = ThemeArchetype.FOOTBALL,
                    customAccentHex = team.primaryColorHex,
                    useDynamicColors = false
                )
            }
            refreshFootballHub(teamId)
        }
    }

    fun saveFootballApiConfiguration(apiKey: String, provider: String, enableNotifications: Boolean) {
        viewModelScope.launch {
            container.preferencesRepository.updateFootballApiConfig(apiKey, provider, enableNotifications)
            refreshFootballHub(uiState.value.preferences.primaryTeamId)
            _statusMessage.value = if (uiState.value.isArabic) {
                "تم حفظ إعدادات Football API وتحديث البيانات."
            } else {
                "Football API settings saved and hub refreshed."
            }
        }
    }

    fun triggerMatchTestNotification() {
        val teamId = uiState.value.preferences.primaryTeamId
        val team = container.footballRepository.getTeamById(teamId)
        container.footballRepository.sendMatchdayTestNotification(team, uiState.value.isArabic)
    }

    // Lock Screen Customization
    fun updateLockScreenConfig(config: LockScreenConfig, syncWallpaperToSystemLock: Boolean = false) {
        viewModelScope.launch {
            container.preferencesRepository.updateLockScreenConfig(config)
            if (syncWallpaperToSystemLock) {
                container.systemControlController.applyPresetWallpaperToSystem(
                    preset = config.wallpaperPreset,
                    applyToHome = false,
                    applyToLock = true
                )
            }
            _statusMessage.value = if (uiState.value.isArabic) {
                "تم حفظ إعدادات شاشة القفل المخصصة."
            } else {
                "Lock screen configuration saved."
            }
        }
    }

    // System Quick Control Actions
    fun refreshSystemTelemetry() = container.systemControlController.refreshTelemetry()
    fun openWifiQuickPanel() = container.systemControlController.openWifiQuickPanel()
    fun openBluetoothSettings() = container.systemControlController.openBluetoothSettings()
    fun openVolumePanel() = container.systemControlController.openVolumePanel()
    fun setMediaVolume(percent: Int) = container.systemControlController.setMediaVolumePercent(percent)
    fun setRingVolume(percent: Int) = container.systemControlController.setRingVolumePercent(percent)
    fun setBrightness(percent: Int) {
        val ok = container.systemControlController.setBrightnessPercent(percent)
        if (!ok) {
            container.systemControlController.requestWriteSettingsPermission()
        }
    }
    fun toggleFlashlight() = container.systemControlController.toggleFlashlight()
    fun openBatteryOptimizationSettings() = container.systemControlController.openBatteryOptimizationSettings()
    fun openDefaultHomeSettings() = container.systemControlController.openDefaultHomeRoleSettings()

    // Backup & Restore Actions
    fun exportBackupToUri(uri: Uri) {
        viewModelScope.launch {
            val result = container.backupRestoreManager.exportBackupToUri(uri, uiState.value.preferences)
            _statusMessage.value = if (result.isSuccess) {
                if (uiState.value.isArabic) "تم تصدير ملف النسخة الاحتياطية بنجاح."
                else "Backup exported to external JSON file."
            } else {
                if (uiState.value.isArabic) "تعذر تصدير النسخة الاحتياطية."
                else "Failed to export backup file."
            }
        }
    }

    fun importBackupFromUri(uri: Uri) {
        viewModelScope.launch {
            val result = container.backupRestoreManager.importBackupFromUri(uri)
            _statusMessage.value = if (result.isSuccess) {
                if (uiState.value.isArabic) "تم استيراد واستعادة النسخة الاحتياطية بنجاح!"
                else "External backup imported and restored."
            } else {
                if (uiState.value.isArabic) "ملف النسخة الاحتياطية غير صالح."
                else "Invalid backup JSON file."
            }
        }
    }
}

class VyroViewModelFactory(private val container: VyroAppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return VyroMainViewModel(container) as T
    }
}
