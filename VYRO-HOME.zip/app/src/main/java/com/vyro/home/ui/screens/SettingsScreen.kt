package com.vyro.home.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyro.home.BuildConfig
import com.vyro.home.data.local.LayoutSnapshotEntity
import com.vyro.home.data.model.IconShapeStyle
import com.vyro.home.data.model.ThemeArchetype
import com.vyro.home.data.model.WallpaperPreset
import com.vyro.home.ui.viewmodel.VyroUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    uiState: VyroUiState,
    onSwitchLanguage: (String) -> Unit,
    onSelectTheme: (ThemeArchetype, Long, Boolean) -> Unit,
    onSelectWallpaper: (WallpaperPreset, Boolean, Boolean) -> Unit,
    onSelectIconShape: (IconShapeStyle) -> Unit,
    onUpdateGridAndScale: (Int, Int, Float) -> Unit,
    onUndoLayout: () -> Unit,
    onRestoreSnapshot: (LayoutSnapshotEntity) -> Unit,
    onExportBackup: (Uri) -> Unit,
    onImportBackup: (Uri) -> Unit,
    onOpenFootballHub: () -> Unit,
    onOpenLockStudio: () -> Unit,
    onOpenSamsungCenter: () -> Unit,
    onOpenWizard: () -> Unit,
    onOpenBatterySettings: () -> Unit,
    onOpenDefaultHomeSettings: () -> Unit,
    onBack: () -> Unit
) {
    val isAr = uiState.isArabic
    val prefs = uiState.preferences

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) onExportBackup(uri)
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) onImportBackup(uri)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = if (isAr) "إعدادات VYRO HOME الشاملة" else "VYRO HOME SETTINGS & BACKUP",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Set Default Home Launcher Button
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isAr) "تعيين VYRO HOME كلانشر افتراضي" else "Set VYRO HOME as Default Launcher",
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isAr) "لا يمس أو يضر إعدادات اللانشر الأصلي للجهاز" else "Does not alter or damage your stock system launcher",
                                fontSize = 11.sp
                            )
                        }
                        Button(onClick = onOpenDefaultHomeSettings) {
                            Icon(Icons.Default.Home, contentDescription = null)
                            Text(if (isAr) " تعيين" else " Set Home")
                        }
                    }
                }
            }

            // 1. Language (Arabic RTL & English)
            item {
                SettingsSectionCard(title = if (isAr) "1. اللغة والاتجاه (العربية / English)" else "1. Language & RTL Direction") {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilterChip(
                            selected = !isAr,
                            onClick = { onSwitchLanguage("en") },
                            label = { Text("English (LTR)") }
                        )
                        FilterChip(
                            selected = isAr,
                            onClick = { onSwitchLanguage("ar") },
                            label = { Text("العربية (RTL دعم كامل)") }
                        )
                    }
                }
            }

            // 2. Appearance & Themes
            item {
                SettingsSectionCard(title = if (isAr) "2. المظهر والثيمات" else "2. Appearance & Theme Engine") {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ThemeArchetype.entries.forEach { arch ->
                            FilterChip(
                                selected = prefs.themeArchetype == arch,
                                onClick = { onSelectTheme(arch, arch.primaryHex, false) },
                                label = { Text(if (isAr) arch.titleAr else arch.titleEn, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }

            // 3. Wallpapers & Icons
            item {
                SettingsSectionCard(title = if (isAr) "3. الخلفيات وشكل الأيقونات" else "3. Wallpapers & Icon Shapes") {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        WallpaperPreset.entries.forEach { wp ->
                            FilterChip(
                                selected = prefs.wallpaperPreset == wp,
                                onClick = { onSelectWallpaper(wp, true, false) },
                                label = { Text(if (isAr) wp.nameAr else wp.nameEn, fontSize = 11.sp) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconShapeStyle.entries.forEach { shape ->
                            FilterChip(
                                selected = prefs.iconShapeStyle == shape,
                                onClick = { onSelectIconShape(shape) },
                                label = { Text(if (isAr) shape.labelAr else shape.labelEn, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }

            // 4. Layout, Grid & Undo
            item {
                SettingsSectionCard(title = if (isAr) "4. الشبكة، التخطيط، والتراجع" else "4. Layout, Grid & Undo Stack") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(4 to 5, 4 to 6, 5 to 5, 5 to 6).forEach { (c, r) ->
                            FilterChip(
                                selected = prefs.activeLayoutState.gridColumns == c && prefs.activeLayoutState.gridRows == r,
                                onClick = { onUpdateGridAndScale(c, r, prefs.activeLayoutState.iconScale) },
                                label = { Text("${c}x${r}") }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onUndoLayout) {
                            Icon(Icons.Default.Undo, contentDescription = null)
                            Text(if (isAr) " تراجع عن آخر تغيير" else " Undo Last Change")
                        }
                        OutlinedButton(onClick = onOpenWizard) {
                            Text(if (isAr) "إعادة تشغيل المعالج" else "Re-run Auto Wizard")
                        }
                    }
                }
            }

            // 5. Backup & Restore (Requirement 11)
            item {
                SettingsSectionCard(title = if (isAr) "5. النسخ الاحتياطي والاستعادة (Backup & Restore)" else "5. Backup & Restore") {
                    Text(
                        text = if (isAr) {
                            "تنبيه هام: إلغاء تثبيت التطبيق من أندرويد قد يؤدي إلى حذف بياناته المحلية. للاحتفاظ الدائم بتخصيصاتك، قم بتصدير ملف النسخة الاحتياطية الخارجي (JSON) أو تفعيل النسخ الاحتياطي السحابي لأندرويد."
                        } else {
                            "Important Notice: Uninstalling an Android app deletes its internal sandbox data. For persistent recovery across reinstalls, export an external JSON backup file below or keep Android Cloud Auto Backup enabled."
                        },
                        fontSize = 12.sp,
                        color = Color(0xFFFDE68A)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { exportLauncher.launch("vyro_home_backup.json") },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Backup, contentDescription = null)
                            Text(if (isAr) " تصدير JSON" else " Export JSON")
                        }
                        OutlinedButton(
                            onClick = { importLauncher.launch(arrayOf("application/json", "*/*")) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Restore, contentDescription = null)
                            Text(if (isAr) " استيراد JSON" else " Import JSON")
                        }
                    }
                    if (uiState.layoutSnapshots.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isAr) "سجل التخطيطات المحفوظة (اضغط للاستعادة):" else "Saved Layout History (Tap to Restore):",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                        uiState.layoutSnapshots.take(4).forEach { snap ->
                            Text(
                                text = "↺ ${snap.label}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onRestoreSnapshot(snap) }
                                    .padding(vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // 6. Quick Navigation to Football Hub, Lock Screen Studio, Samsung Center & Battery
            item {
                SettingsSectionCard(title = if (isAr) "6. المراكز المتخصصة والطاقة" else "6. Specialized Hubs, Privacy & Battery") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onOpenFootballHub, modifier = Modifier.weight(1f)) {
                            Text(if (isAr) "مركز كرة القدم" else "Football Hub", fontSize = 12.sp)
                        }
                        OutlinedButton(onClick = onOpenLockStudio, modifier = Modifier.weight(1f)) {
                            Text(if (isAr) "شاشة القفل" else "Lock Studio", fontSize = 12.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onOpenSamsungCenter, modifier = Modifier.weight(1f)) {
                            Text(if (isAr) "تخصيص سامسونج" else "Samsung & OEM", fontSize = 12.sp)
                        }
                        OutlinedButton(onClick = onOpenBatterySettings, modifier = Modifier.weight(1f)) {
                            Text(if (isAr) "تحسين البطارية" else "Battery Opt", fontSize = 12.sp)
                        }
                    }
                }
            }

            // 7. Device Information & About VYRO HOME
            item {
                SettingsSectionCard(title = if (isAr) "7. حول VYRO HOME ومعلومات الجهاز" else "7. About VYRO HOME & Device Info") {
                    val r = uiState.deviceReport
                    Text("• App Name: VYRO HOME (${BuildConfig.VERSION_NAME})", fontSize = 12.sp)
                    Text("• Compatibility Policy: Android 16 (minSdk 36) — Android 17 (targetSdk ${BuildConfig.CONFIGURED_TARGET_SDK})", fontSize = 12.sp)
                    Text("• Runtime Device: ${r.manufacturer} ${r.model} (${r.androidGenerationLabel})", fontSize = 12.sp)
                    Text("• Samsung One UI: ${r.oneUiVersionLabel}", fontSize = 12.sp)
                    Text("• Architecture: Kotlin + Jetpack Compose + Material 3 + Room + DataStore", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                fontSize = 15.sp
            )
            content()
        }
    }
}
