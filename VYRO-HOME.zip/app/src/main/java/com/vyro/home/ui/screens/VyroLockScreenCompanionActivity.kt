package com.vyro.home.ui.screens

import android.app.KeyguardManager
import android.content.Context
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vyro.home.VyroHomeApplication
import com.vyro.home.data.preferences.UserPreferencesState
import com.vyro.home.ui.theme.VyroHomeTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Opt-in VYRO Lock-Screen Ambient Companion Activity.
 * Uses official Android Activity.setShowWhenLocked(true) and KeyguardManager.requestDismissKeyguard()
 * so native PIN, pattern, or biometric security is 100% respected and never bypassed.
 */
class VyroLockScreenCompanionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        enableEdgeToEdge()

        val container = (application as VyroHomeApplication).container

        setContent {
            val prefs by container.preferencesRepository.preferencesFlow.collectAsState(
                initial = UserPreferencesState()
            )
            val lockCfg = prefs.lockScreenConfig
            val wp = lockCfg.wallpaperPreset
            val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            val dateStr = SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(Date())

            VyroHomeTheme(archetype = prefs.themeArchetype, customAccentHex = prefs.customAccentHex) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(wp.topColorHex), Color(wp.midColorHex), Color(wp.bottomColorHex))
                            )
                        )
                        .systemBarsPadding()
                        .padding(24.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "VYRO AMBIENT LOCK COMPANION",
                            color = Color(0xFF94A3B8),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = timeStr,
                                fontSize = 64.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            if (lockCfg.showDate) {
                                Text(
                                    text = "$dateStr • 24°C",
                                    fontSize = 15.sp,
                                    color = Color(0xFFCBD5E1)
                                )
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            if (lockCfg.showFootballWidget) {
                                Card(
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color(0x4410B981))
                                ) {
                                    Text(
                                        text = "⚽ ${prefs.primaryTeamId} Matchday Hub Active",
                                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { container.systemControlController.toggleFlashlight() }) {
                                Icon(Icons.Default.FlashlightOn, contentDescription = "Torch", tint = Color.White)
                            }

                            Button(onClick = {
                                val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                                if (km.isKeyguardLocked) {
                                    km.requestDismissKeyguard(this@VyroLockScreenCompanionActivity, null)
                                }
                                finish()
                            }) {
                                Icon(Icons.Default.LockOpen, contentDescription = null)
                                Text("  Unlock to VYRO HOME")
                            }
                        }
                    }
                }
            }
        }
    }
}
