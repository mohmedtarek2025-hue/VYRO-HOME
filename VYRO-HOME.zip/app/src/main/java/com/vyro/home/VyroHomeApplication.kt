package com.vyro.home

import android.app.Application
import com.vyro.home.core.device.DeviceCapabilityManager
import com.vyro.home.core.system.SystemControlController
import com.vyro.home.data.backup.BackupRestoreManager
import com.vyro.home.data.local.VyroDatabase
import com.vyro.home.data.preferences.VyroPreferencesRepository
import com.vyro.home.domain.engine.AutoLayoutEngine
import com.vyro.home.domain.engine.LauncherAppRepository
import com.vyro.home.domain.football.FootballRepository

class VyroAppContainer(application: Application) {
    val database: VyroDatabase by lazy { VyroDatabase.getInstance(application) }
    val preferencesRepository: VyroPreferencesRepository by lazy { VyroPreferencesRepository(application) }
    val deviceCapabilityManager: DeviceCapabilityManager by lazy { DeviceCapabilityManager(application) }
    val systemControlController: SystemControlController by lazy { SystemControlController(application) }
    val launcherAppRepository: LauncherAppRepository by lazy { LauncherAppRepository(application) }
    val autoLayoutEngine: AutoLayoutEngine by lazy { AutoLayoutEngine() }
    val footballRepository: FootballRepository by lazy { FootballRepository(application, database.vyroDao()) }
    val backupRestoreManager: BackupRestoreManager by lazy {
        BackupRestoreManager(application, preferencesRepository, database.vyroDao())
    }
}

class VyroHomeApplication : Application() {
    lateinit var container: VyroAppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = VyroAppContainer(this)
    }
}
