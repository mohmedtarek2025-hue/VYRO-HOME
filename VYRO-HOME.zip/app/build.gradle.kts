import java.io.FileInputStream
import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
}

val localProps = Properties().apply {
    val file = rootProject.file("local.properties")
    if (file.exists()) {
        FileInputStream(file).use { load(it) }
    }
}

/**
 * Resolves whether Android 17 (API 37) platform SDK is installed in the current build environment.
 * Requirement 1:
 * - Set minSdk to 36 (Android 16).
 * - Set targetSdk to 37 (Android 17) if the available Android SDK and build environment support it;
 *   otherwise use the highest supported target SDK (36) and clearly document the limitation.
 */
fun resolveSupportedTargetSdk(): Int {
    val requestedTarget = (project.findProperty("vyro.targetSdk")?.toString()?.toIntOrNull()) ?: 37
    val sdkDirProp = localProps.getProperty("sdk.dir")
        ?: System.getenv("ANDROID_HOME")
        ?: System.getenv("ANDROID_SDK_ROOT")
    if (sdkDirProp != null) {
        val api37Dir = File(sdkDirProp, "platforms/android-37")
        val api36Dir = File(sdkDirProp, "platforms/android-36")
        if (requestedTarget >= 37 && api37Dir.exists()) {
            logger.lifecycle("VYRO HOME Build: Detected Android 17 SDK (platforms/android-37). Using compileSdk=37, targetSdk=37.")
            return 37
        } else if (api36Dir.exists()) {
            logger.lifecycle("VYRO HOME Build: platforms/android-37 not installed in SDK; falling back to highest installed SDK 36 (Android 16).")
            return 36
        }
    }
    return requestedTarget
}

val resolvedTopSdk = resolveSupportedTargetSdk()
val footballApiKey: String = localProps.getProperty("FOOTBALL_API_KEY")
    ?: System.getenv("FOOTBALL_API_KEY")
    ?: ""
val footballApiProvider: String = localProps.getProperty("FOOTBALL_API_PROVIDER")
    ?: System.getenv("FOOTBALL_API_PROVIDER")
    ?: "FOOTBALL_DATA_ORG"

android {
    namespace = "com.vyro.home"
    compileSdk = resolvedTopSdk

    defaultConfig {
        applicationId = "com.vyro.home"
        // Strictly support ONLY Android 16 (API 36) and Android 17 (API 37)
        minSdk = 36
        targetSdk = resolvedTopSdk
        versionCode = 100
        versionName = "1.0.0-FUTURA"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        buildConfigField("String", "FOOTBALL_API_KEY", "\"$footballApiKey\"")
        buildConfigField("String", "FOOTBALL_API_PROVIDER", "\"$footballApiProvider\"")
        buildConfigField("int", "CONFIGURED_TARGET_SDK", "$resolvedTopSdk")
    }

    androidResources {
        generateLocaleConfig = true
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-DEBUG"
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.core.splashscreen)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)

    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.datastore.preferences)

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    implementation(libs.androidx.work.runtime.ktx)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.kotlinx.coroutines.android)

    debugImplementation(libs.androidx.compose.ui.tooling)
    testImplementation(libs.junit)
}
