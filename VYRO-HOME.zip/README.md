# VYRO HOME — Futuristic Autonomous Android 16 & 17 Launcher

**VYRO HOME** is a complete, production-grade Android Home Launcher built in **Kotlin**, **Jetpack Compose**, and **Material 3** exclusively for **Android 16 (API 36)** and **Android 17 (API 37)**. It combines an automatic personalization engine, non-destructive smart folder layout generation, a dedicated **Football Hub** (FC Barcelona, Real Madrid, Egypt National Team, and more), a **Samsung One UI Adaptation Engine**, a **Lock-Screen Customization Studio**, a **Quick Control Center**, and full **Arabic (RTL) & English (LTR)** localization.

---

## 1. Android 16 (API 36) & Android 17 (API 37) Compatibility Policy

- **Strict Minimum SDK**: `minSdk = 36` ([Android 16 SDK Setup](https://developer.android.com/about/versions/16/setup-sdk)). Android versions below 16 are intentionally not supported.
- **Target & Compile SDK**: Configured for `targetSdk = 37` and `compileSdk = 37` ([Android 17 SDK Setup](https://developer.android.com/about/versions/17/setup-sdk) and [Android 17 Behavior Changes](https://developer.android.com/about/versions/17/behavior-changes-17)).
- **Automatic Build Environment Fallback**: In `app/build.gradle.kts`, `resolveSupportedTargetSdk()` inspects `$ANDROID_HOME/platforms/android-37`. When `platforms;android-37` is installed, it compiles and targets API 37. If a CI runner or local SDK installation only has `platforms;android-36` available in its stable channel, Gradle logs a clear diagnostic notice and compiles cleanly against API 36 without breaking the build.
- **Samsung & One UI Runtime Detection**: `DeviceCapabilityManager.kt` inspects `Build.MANUFACTURER`, `Build.BRAND`, `PackageManager.hasSystemFeature("com.samsung.feature.samsung_experience_mobile")`, `Build.VERSION.SEM_PLATFORM_INT`, and `ro.build.version.oneui`. It identifies **One UI 9.0** (`SEM_PLATFORM_INT >= 180000` / `ro.build.version.oneui >= 90000`) when running on One UI 9.0 firmware, and **never falsely claims One UI 9.0 compatibility** when running on earlier One UI releases or non-Samsung devices.

---

## 2. Core Features & Legitimate Android API Architecture

1. **Cinematic Start Screen (`StartScreen.kt`)**:
   - Custom animated orbital VYRO emblem rendered on Jetpack Compose `Canvas`, multi-stop nebula gradients, live hardware/API badge, instant **English / العربية** language switcher with immediate RTL/LTR layout mirroring, and smooth navigation into the Personalization Wizard.
2. **Automatic Personalization Wizard (`PersonalizationWizardScreen.kt`)**:
   - 4-step guided setup allowing users to select from **10 theme archetypes** (Dark, Light, AMOLED, Calm, Neon, Minimal, Luxury, Gaming, Football, Nature), custom accent colors, dynamic wallpaper color extraction, wallpaper presets, icon shapes, grid sizing (`4x5`, `4x6`, `5x5`, `5x6`), widgets, personal interests, and favorite football teams.
   - Generates a complete launcher layout automatically with a **Preview Before Applying** modal.
3. **Auto-Layout Engine (`AutoLayoutEngine.kt` & `LauncherAppRepository.kt`)**:
   - Queries real installed launchable activities via Android's official [`LauncherApps`](https://developer.android.com/reference/android/content/pm/LauncherApps) API (`getActivityList`).
   - Categorizes apps into Smart Folders (`Football & Sports`, `Gaming Arena`, `Productivity & Work`, `Social & Communication`, `Media & Entertainment`, `Finance & Banking`, `Tools & Utilities`), populates the custom dock, and records every layout change in a Room database (`LayoutSnapshotEntity`) for one-tap **Undo Changes** and **Restore Previous Layouts**.
   - **Strict Non-Destructive Guarantee**: VYRO HOME never deletes, uninstalls, disables, or modifies user-installed packages or the stock system launcher.
4. **Football Hub (`FootballHubScreen.kt` & `FootballRepository.kt`)**:
   - First-class support for **FC Barcelona**, **Real Madrid**, **Egypt National Team (الفراعنة)**, **Al Ahly SC**, **Zamalek SC**, **Liverpool FC**, **Manchester City**, and **Arsenal FC**.
   - Modular REST integration supporting [`football-data.org` API v4](https://docs.football-data.org/general/v4/index.html) and [`API-Football` v3](https://www.api-football.com/).
   - **Zero Hardcoded Fake Live Scores**: When no API key is configured, fixture pairings are explicitly marked `API_KEY_REQUIRED` with `null` scores (`VS`) and a clear banner guiding the user to add their key.
5. **Lock-Screen Customization Studio (`LockScreenStudioScreen.kt` & `VyroLockScreenCompanionActivity.kt`)**:
   - Customizes clock styles, date/weather telemetry, football matchday lock pill, notification privacy modes, and applies procedural wallpapers directly to the system lock screen via [`WallpaperManager.setBitmap(..., FLAG_LOCK)`](https://developer.android.com/reference/android/app/WallpaperManager).
   - Includes an opt-in Ambient Lock-Screen Companion (`setShowWhenLocked(true)`) that uses `KeyguardManager.requestDismissKeyguard()` so native PIN, pattern, and biometric security are 100% respected and never bypassed.
6. **Quick Settings & Control Center (`QuickControlPanelSheet.kt` & `SystemControlController.kt`)**:
   - Normal Android launchers cannot replace the privileged `SystemUI` notification shade on unrooted devices. VYRO HOME transparently documents this and provides both:
     - A swipe-up/one-tap **VYRO Control Center** using official [`Settings.Panel`](https://developer.android.com/reference/android/provider/Settings.Panel) slices (`ACTION_INTERNET_CONNECTIVITY`, `ACTION_VOLUME`), real-time `AudioManager` sliders, `Settings.System.SCREEN_BRIGHTNESS` control, hardware `CameraManager.setTorchMode` flashlight toggle, and live `BatteryManager` telemetry.
     - An official system [`TileService`](https://developer.android.com/develop/ui/views/quicksettings-tiles) (`VyroQuickTileService`) that users can add to their native Android Quick Settings panel.
7. **Complete Arabic (RTL) & English Support (`res/values/strings.xml`, `res/values-ar/strings.xml`, `LocaleHelper.kt`)**:
   - Uses Android's official [Per-App Language Preferences (`AppCompatDelegate.setApplicationLocales`)](https://developer.android.com/guide/topics/resources/app-languages) and Compose `CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl)` for instant, native Arabic RTL layout mirroring.
8. **Backup & Restore (`BackupRestoreManager.kt` & `VyroBackupAgent.kt`)**:
   - Combines Jetpack DataStore, Room layout snapshots, external JSON file export/import via Android Storage Access Framework (`CreateDocument` / `OpenDocument`), and [Android Auto Backup](https://developer.android.com/identity/data/autobackup) (`backup_rules.xml` & `data_extraction_rules.xml`).

---

## 3. Configuring Football Hub Live API Keys

You can configure a live football API key either at build time or inside the app at runtime:

### Option A: In-App Configuration (Recommended for Users)
1. Open **VYRO HOME** → tap the **Football Hub** chip (or go to **Settings → Football Hub**).
2. Tap the **Key Icon** in the top-right corner of the Football Hub screen.
3. Select your provider (`football-data.org` or `API-Football`), paste your API token, and tap **Save & Sync**.

### Option B: Build-Time / GitHub Actions Configuration
1. Register for a free API token at [football-data.org Registration](https://www.football-data.org/client/register).
2. For local builds, copy `local.properties.example` to `local.properties` and add:
   ```properties
   FOOTBALL_API_PROVIDER=FOOTBALL_DATA_ORG
   FOOTBALL_API_KEY=your_api_token_here
   ```
3. For GitHub Actions builds, add `FOOTBALL_API_KEY` under your repository's **Settings → Secrets and variables → Actions**.

---

## 4. Building Locally & via GitHub Actions

### Local Build Instructions
1. Install **Android Studio Meerkat / Panda** or newer with **JDK 17** and **Android SDK Platform 36 (Android 16)** / **Platform 37 (Android 17)** ([Set up the Android 17 SDK](https://developer.android.com/about/versions/17/setup-sdk)).
2. From the project root, run:
   ```bash
   chmod +x ./gradlew
   ./gradlew assembleDebug --stacktrace
   ```
   *(Note: If `gradle/wrapper/gradle-wrapper.jar` is not present locally, `./gradlew` automatically bootstraps it from the official Gradle 8.11.1 release before starting the build.)*
3. The compiled APK will be generated at:
   `app/build/outputs/apk/debug/app-debug.apk`

### GitHub Actions Automated APK Build
1. Push this repository to GitHub (`main`, `master`, or `develop` branch) or trigger **Actions → VYRO HOME Android CI Build → Run workflow**.
2. The workflow (`.github/workflows/android-build.yml`) provisions Temurin JDK 17, installs Android SDK Build-Tools 36.0.0 and Platforms 36 & 37, runs unit tests, compiles the debug APK, and uploads **`VYRO-HOME-debug-apk`** as a downloadable workflow artifact.
