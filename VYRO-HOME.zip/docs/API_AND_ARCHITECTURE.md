# VYRO HOME — Architecture, Platform Restrictions & API Reference

## 1. Platform Restrictions & Legitimate Alternatives Implemented

| Feature Area | Android Platform Restriction (API 36 / 37) | Legitimate VYRO HOME Implementation |
| :--- | :--- | :--- |
| **System Quick Settings Replacement** | Third-party apps cannot overwrite the system `SystemUI` notification/quick-settings shade without root or OEM system signatures. | Implements an in-launcher **VYRO Control Center** modal sheet using [`Settings.Panel`](https://developer.android.com/reference/android/provider/Settings.Panel), `AudioManager`, `CameraManager` torch, and `Settings.System` brightness, plus a native [`TileService`](https://developer.android.com/develop/ui/views/quicksettings-tiles) (`VyroQuickTileService`). |
| **System Lock Screen Replacement** | Third-party launchers cannot disable or bypass `KeyguardManager`, PIN, pattern, or biometric authentication. | Applies custom procedural lock-screen wallpapers via [`WallpaperManager.FLAG_LOCK`](https://developer.android.com/reference/android/app/WallpaperManager) and provides an opt-in `VyroLockScreenCompanionActivity` (`setShowWhenLocked(true)`) that delegates unlocking to `KeyguardManager.requestDismissKeyguard()`. |
| **Samsung Good Lock / Theme Park / Home Up** | Good Lock modules (`Home Up`, `Theme Park`) use private Samsung signature permissions unavailable to third-party apps. | Inspects package installation status honestly via `PackageManager`, never fakes access to privileged Samsung APIs, and provides built-in One UI squircle geometry (`38%` curvature) and One UI ergonomic thumb-reach headers directly inside VYRO HOME. |
| **One UI 9.0 Detection** | One UI 9.0 corresponds to Samsung's Android 17 (API 37) platform (`SEM_PLATFORM_INT >= 180000`). | `DeviceCapabilityManager` reads `SEM_PLATFORM_INT` and `ro.build.version.oneui` safely at runtime and only reports One UI 9.0 when genuinely running on One UI 9.0 firmware. |
| **App Uninstall Data Persistence** | Android deletes internal app storage (`/data/data/com.vyro.home`) when an app is uninstalled. | Combines [Android Auto Backup](https://developer.android.com/identity/data/autobackup) (`VyroBackupAgent` + `data_extraction_rules.xml`) with user-controlled external JSON export/import via Android Storage Access Framework (`ActivityResultContracts.CreateDocument`). |

## 2. Football API Configuration Reference

- **Primary Supported Endpoint**: [`football-data.org` v4](https://docs.football-data.org/general/v4/index.html)
  - Team Matches Endpoint: `GET https://api.football-data.org/v4/teams/{id}/matches?limit=10`
  - Competition Standings Endpoint: `GET https://api.football-data.org/v4/competitions/{code}/standings`
  - Header: `X-Auth-Token: <YOUR_API_KEY>`
- **Pre-Configured Club IDs**:
  - **FC Barcelona**: `footballDataOrgId = 81`, `apiFootballId = 529`, Competition `PD`
  - **Real Madrid CF**: `footballDataOrgId = 86`, `apiFootballId = 541`, Competition `PD`
  - **Egypt National Team**: `footballDataOrgId = 825`, `apiFootballId = 32`, Competition `WC`
  - **Al Ahly SC**: `footballDataOrgId = 6684`, `apiFootballId = 1029`, Competition `CAF`
  - **Zamalek SC**: `footballDataOrgId = 6685`, `apiFootballId = 1040`, Competition `CAF`
  - **Liverpool FC**: `footballDataOrgId = 64`, `apiFootballId = 40`, Competition `PL`
  - **Manchester City**: `footballDataOrgId = 65`, `apiFootballId = 50`, Competition `PL`
  - **Arsenal FC**: `footballDataOrgId = 57`, `apiFootballId = 42`, Competition `PL`
